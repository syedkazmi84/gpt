<?php
namespace AWHB;

if (!defined('ABSPATH')) { exit; }

final class Block {

    public static function init() {
        add_action('init', array(__CLASS__, 'register_block'));
        add_shortcode('authorwings_hybrid_builder', array(__CLASS__, 'shortcode'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'register_assets'));
    }

    public static function register_assets() {
        wp_register_style('awhb-frontend', AWHB_URL . 'assets/frontend.css', array(), AWHB_VERSION);
        wp_register_script('awhb-frontend', AWHB_URL . 'assets/frontend.js', array(), AWHB_VERSION, true);
    }

    public static function enqueue_frontend() {
        wp_enqueue_style('awhb-frontend');
        wp_enqueue_script('awhb-frontend');
        wp_localize_script('awhb-frontend', 'AWHB', array(
            'restUrl' => esc_url_raw(rest_url('authorwings/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
        ));
    }

    public static function register_block() {
        if (!function_exists('register_block_type')) return;

        wp_register_script(
            'awhb-block-editor',
            AWHB_URL . 'assets/block-editor.js',
            array('wp-blocks','wp-element'),
            AWHB_VERSION,
            true
        );

        register_block_type('authorwings/hybrid-builder', array(
            'api_version' => 2,
            'editor_script' => 'awhb-block-editor',
            'render_callback' => array(__CLASS__, 'render'),
            'attributes' => array(),
        ));
    }

    public static function render($attrs = array(), $content = '') {
        self::enqueue_frontend();
        ob_start();
        ?>
        <div class="awhb" data-awhb-root="1">
            <noscript><?php esc_html_e('Please enable JavaScript to use the calculator.', 'authorwings-hybrid-builder'); ?></noscript>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function shortcode($atts = array()) {
        return self::render();
    }
}
