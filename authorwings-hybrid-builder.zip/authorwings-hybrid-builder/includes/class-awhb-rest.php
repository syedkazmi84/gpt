<?php
namespace AWHB;

if (!defined('ABSPATH')) { exit; }

final class REST {

    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'routes'));
    }

    public static function routes() {
        register_rest_route('authorwings/v1', '/config', array(
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => array(__CLASS__, 'get_config'),
        ));

        register_rest_route('authorwings/v1', '/quote', array(
            'methods' => 'POST',
            'permission_callback' => array(__CLASS__, 'can_submit_quote'),
            'callback' => array(__CLASS__, 'submit_quote'),
            'args' => array(
                'name' => array('required' => true),
                'email' => array('required' => true),
            ),
        ));
    }

    public static function can_submit_quote($request) {
        $nonce = $request->get_header('X-WP-Nonce');
        if (!$nonce) {
            $nonce = $request->get_param('_wpnonce');
        }
        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('awhb_invalid_nonce', __('Invalid request token.', 'authorwings-hybrid-builder'), array('status' => 403));
        }
        return true;
    }

    public static function get_config($request) {
        $settings = Helpers::get_settings();
        $services = array_values(array_filter(Helpers::get_services(), function($s) {
            return !empty($s['active']);
        }));

        return rest_ensure_response(array(
            'settings' => $settings,
            'services' => $services,
        ));
    }

    public static function submit_quote($request) {
        $settings = Helpers::get_settings();

        $name = sanitize_text_field($request->get_param('name'));
        $email = sanitize_email($request->get_param('email'));
        $phone = sanitize_text_field($request->get_param('phone'));
        $notes = sanitize_textarea_field($request->get_param('notes'));

        $payload = $request->get_param('payload');
        if (is_string($payload)) {
            $payload = json_decode($payload, true);
        }
        if (!is_array($payload)) $payload = array();

        if (!$name || !is_email($email)) {
            return new \WP_Error('invalid', __('Please provide a valid name and email.', 'authorwings-hybrid-builder'), array('status' => 400));
        }
        if (!empty($settings['require_phone']) && !$phone) {
            return new \WP_Error('invalid_phone', __('Phone is required.', 'authorwings-hybrid-builder'), array('status' => 400));
        }

        $to = sanitize_email($settings['email_to'] ?? get_option('admin_email'));
        $subject = sprintf('AuthorWings Quote Request: %s', $name);

        $body = "New quote request\n\n";
        $body .= "Name: {$name}\n";
        $body .= "Email: {$email}\n";
        if ($phone) $body .= "Phone: {$phone}\n";
        $body .= "\n--- Selection ---\n";
        $body .= wp_json_encode($payload, JSON_PRETTY_PRINT) . "\n";
        if ($notes) {
            $body .= "\n--- Notes ---\n{$notes}\n";
        }

        wp_mail($to, $subject, $body, array('Content-Type: text/plain; charset=UTF-8'));

        return rest_ensure_response(array('ok' => true));
    }
}
