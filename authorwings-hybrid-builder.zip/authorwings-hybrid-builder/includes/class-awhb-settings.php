<?php
namespace AWHB;

if (!defined('ABSPATH')) { exit; }

final class Settings {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'register'));
        add_action('admin_notices', array(__CLASS__, 'maybe_notice_demo'));
        add_action('admin_post_awhb_import_demo', array(__CLASS__, 'handle_import_demo'));
        add_action('admin_post_awhb_remove_demo', array(__CLASS__, 'handle_remove_demo'));
    }

    public static function menu() {
        add_menu_page(
            __('AuthorWings Calculator', 'authorwings-hybrid-builder'),
            __('AuthorWings', 'authorwings-hybrid-builder'),
            'manage_options',
            'awhb',
            array(__CLASS__, 'page'),
            'dashicons-calculator',
            25
        );

        add_submenu_page('awhb', __('Settings', 'authorwings-hybrid-builder'), __('Settings', 'authorwings-hybrid-builder'), 'manage_options', 'awhb', array(__CLASS__, 'page'));
    }


    public static function register() {
        register_setting('awhb_settings_group', 'awhb_settings', array(
            'type' => 'array',
            'sanitize_callback' => array(__CLASS__, 'sanitize'),
            'default' => Helpers::get_settings(),
        ));

        add_settings_section('awhb_main', __('Global Settings', 'authorwings-hybrid-builder'), function() {
            echo '<p class="description">Control calculator defaults and quote routing.</p>';
        }, 'awhb');

        add_settings_field('currency_symbol', __('Currency Symbol', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_currency'), 'awhb', 'awhb_main');
        add_settings_field('default_word_count', __('Default Word Count', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_word'), 'awhb', 'awhb_main');
        add_settings_field('default_page_count', __('Default Page Count', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_page'), 'awhb', 'awhb_main');
        add_settings_field('default_item_count', __('Default Item Count', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_item'), 'awhb', 'awhb_main');
        add_settings_field('email_to', __('Quote Email To', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_email'), 'awhb', 'awhb_main');
        add_settings_field('require_phone', __('Require Phone', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_phone'), 'awhb', 'awhb_main');

        add_settings_section('awhb_demo', __('Demo Data', 'authorwings-hybrid-builder'), function() {
            echo '<p class="description">Import a ready-made set of book publishing + AI services to start faster. You can edit or delete them anytime.</p>';
        }, 'awhb');

        add_settings_field('demo_actions', __('Demo Actions', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_demo_actions'), 'awhb', 'awhb_demo');

    }

    public static function sanitize($in) {
        $out = Helpers::get_settings();
        if (!is_array($in)) return $out;

        $out['currency_symbol'] = sanitize_text_field($in['currency_symbol'] ?? '$');
        $out['default_word_count'] = max(0, (int)($in['default_word_count'] ?? 50000));
        $out['default_page_count'] = max(0, (int)($in['default_page_count'] ?? 200));
        $out['default_item_count'] = max(0, (int)($in['default_item_count'] ?? 1));
        $out['email_to'] = sanitize_email($in['email_to'] ?? get_option('admin_email'));
        $out['require_phone'] = !empty($in['require_phone']) ? 1 : 0;

        return $out;
    }

    public static function page() {
        if (!current_user_can('manage_options')) return;
        wp_enqueue_style('awhb-admin', AWHB_URL . 'assets/admin.css', array(), AWHB_VERSION);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('AuthorWings Calculator Settings', 'authorwings-hybrid-builder'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('awhb_settings_group');
                do_settings_sections('awhb');
                submit_button();
                ?>
            </form>

            <hr/>
            <h2><?php esc_html_e('Use on Pages', 'authorwings-hybrid-builder'); ?></h2>
            <p>
                <?php esc_html_e('Add the “AuthorWings Hybrid Builder” block in Gutenberg, or use shortcode:', 'authorwings-hybrid-builder'); ?>
                <code>[authorwings_hybrid_builder]</code>
            </p>
        </div>
        <?php
    }

    public static function field_currency() {
        $s = Helpers::get_settings();
        printf('<input type="text" name="awhb_settings[currency_symbol]" value="%s" class="regular-text" />', esc_attr($s['currency_symbol']));
    }
    public static function field_word() {
        $s = Helpers::get_settings();
        printf('<input type="number" min="0" step="1" name="awhb_settings[default_word_count]" value="%s" />', esc_attr($s['default_word_count']));
    }
    public static function field_page() {
        $s = Helpers::get_settings();
        printf('<input type="number" min="0" step="1" name="awhb_settings[default_page_count]" value="%s" />', esc_attr($s['default_page_count']));
    }
    public static function field_item() {
        $s = Helpers::get_settings();
        printf('<input type="number" min="0" step="1" name="awhb_settings[default_item_count]" value="%s" />', esc_attr($s['default_item_count']));
    }
    public static function field_email() {
        $s = Helpers::get_settings();
        printf('<input type="email" name="awhb_settings[email_to]" value="%s" class="regular-text" />', esc_attr($s['email_to']));
    }
    public static function field_phone() {
        $s = Helpers::get_settings();
        printf('<label><input type="checkbox" name="awhb_settings[require_phone]" value="1" %s /> %s</label>',
            checked($s['require_phone'], 1, false),
            esc_html__('Require phone in quote form', 'authorwings-hybrid-builder')
        );
    }

    public static function field_demo_actions() {
        if (!current_user_can('manage_options')) { return; }

        $total = wp_count_posts(\AWHB\CPT::POST_TYPE);
        $published = isset($total->publish) ? (int)$total->publish : 0;

        $demo_q = new \WP_Query(array(
            'post_type' => \AWHB\CPT::POST_TYPE,
            'post_status' => 'any',
            'posts_per_page' => 1,
            'meta_key' => '_awhb_is_demo',
            'meta_value' => 1,
            'fields' => 'ids',
        ));
        $has_demo = $demo_q->have_posts();

        $import_url = wp_nonce_url(admin_url('admin-post.php?action=awhb_import_demo'), 'awhb_import_demo');
        $remove_url = wp_nonce_url(admin_url('admin-post.php?action=awhb_remove_demo'), 'awhb_remove_demo');

        echo '<div class="awhb-demo-actions">';
        echo '<p class="description">' . esc_html__('Tip: Import demo services once, then edit prices and options inside AuthorWings → Services.', 'authorwings-hybrid-builder') . '</p>';
        echo '<p><strong>' . esc_html__('Current services:', 'authorwings-hybrid-builder') . '</strong> ' . esc_html($published) . '</p>';

        echo '<p><a class="button button-secondary" href="' . esc_url($import_url) . '">' . esc_html__('Import Demo Services', 'authorwings-hybrid-builder') . '</a></p>';

        if ($has_demo) {
            echo '<p><a class="button button-link-delete" href="' . esc_url($remove_url) . '" onclick="return confirm(\'Remove demo services?\');">' . esc_html__('Remove Demo Services', 'authorwings-hybrid-builder') . '</a></p>';
        } else {
            echo '<p class="description">' . esc_html__('No demo services detected yet.', 'authorwings-hybrid-builder') . '</p>';
        }

        echo '</div>';
    }

    public static function maybe_notice_demo() {
        if (!current_user_can('manage_options')) { return; }
        if (!get_option('awhb_needs_demo_notice')) { return; }

        $count = wp_count_posts(\AWHB\CPT::POST_TYPE);
        $published = isset($count->publish) ? (int)$count->publish : 0;
        if ($published > 0) {
            delete_option('awhb_needs_demo_notice');
            return;
        }

        $import_url = wp_nonce_url(admin_url('admin-post.php?action=awhb_import_demo'), 'awhb_import_demo');
        echo '<div class="notice notice-info is-dismissible">';
        echo '<p><strong>' . esc_html__('AuthorWings:', 'authorwings-hybrid-builder') . '</strong> ' . esc_html__('Import demo book publishing + AI services to start fast.', 'authorwings-hybrid-builder') . '</p>';
        echo '<p><a class="button button-primary" href="' . esc_url($import_url) . '">' . esc_html__('Import Demo Services', 'authorwings-hybrid-builder') . '</a></p>';
        echo '</div>';
    }

    public static function handle_import_demo() {
        if (!current_user_can('manage_options')) { wp_die('Not allowed'); }
        check_admin_referer('awhb_import_demo');

        $count = wp_count_posts(\AWHB\CPT::POST_TYPE);
        $published = isset($count->publish) ? (int)$count->publish : 0;
        if ($published > 0) {
            delete_option('awhb_needs_demo_notice');
            wp_safe_redirect(admin_url('admin.php?page=awhb&awhb_msg=services_exist'));
            exit;
        }

        $demo = self::get_demo_dataset();
        foreach ($demo as $svc) {
            $post_id = wp_insert_post(array(
                'post_type' => \AWHB\CPT::POST_TYPE,
                'post_status' => 'publish',
                'post_title' => $svc['title'],
                'post_content' => $svc['content'],
                'menu_order' => (int)($svc['menu_order'] ?? 0),
            ));

            if (is_wp_error($post_id) || !$post_id) { continue; }

            update_post_meta($post_id, '_awhb_service', $svc['meta']);
            update_post_meta($post_id, '_awhb_is_demo', 1);
        }

        delete_option('awhb_needs_demo_notice');
        wp_safe_redirect(admin_url('admin.php?page=awhb&awhb_msg=demo_imported'));
        exit;
    }

    public static function handle_remove_demo() {
        if (!current_user_can('manage_options')) { wp_die('Not allowed'); }
        check_admin_referer('awhb_remove_demo');

        $q = new \WP_Query(array(
            'post_type' => \AWHB\CPT::POST_TYPE,
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_key' => '_awhb_is_demo',
            'meta_value' => 1,
        ));
        if ($q->have_posts()) {
            foreach ($q->posts as $pid) {
                wp_delete_post($pid, true);
            }
        }

        wp_safe_redirect(admin_url('admin.php?page=awhb&awhb_msg=demo_removed'));
        exit;
    }

    private static function get_demo_dataset() {
        $dataset = Helpers::demo_services_dataset();
        $out = array();
        $order = 0;
        foreach ($dataset as $service) {
            $order++;
            $out[] = array(
                'title' => $service['title'],
                'content' => $service['description'],
                'menu_order' => $order,
                'meta' => array(
                    'active' => 1,
                    'pricing_model' => $service['pricing_model'],
                    'base_price' => $service['base_price'],
                    'unit_price' => $service['unit_price'],
                    'min_charge' => $service['min_charge'],
                    'tier_basic' => $service['tier_basic'],
                    'tier_standard' => $service['tier_standard'],
                    'tier_premium' => $service['tier_premium'],
                    'options' => $service['options'],
                ),
            );
        }
        return $out;
    }


}
