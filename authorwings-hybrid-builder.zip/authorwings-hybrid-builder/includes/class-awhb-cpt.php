<?php
namespace AWHB;

if (!defined('ABSPATH')) { exit; }

final class CPT {
    const POST_TYPE = 'aw_service';

    public static function init() {
        add_action('init', array(__CLASS__, 'register'));
        add_action('add_meta_boxes', array(__CLASS__, 'metaboxes'));
        add_action('save_post_' . self::POST_TYPE, array(__CLASS__, 'save'), 10, 2);

        add_filter('manage_' . self::POST_TYPE . '_posts_columns', array(__CLASS__, 'cols'));
        add_action('manage_' . self::POST_TYPE . '_posts_custom_column', array(__CLASS__, 'col_render'), 10, 2);
    }

    public static function register() {
        register_post_type(self::POST_TYPE, array(
            'labels' => array(
                'name' => __('Services', 'authorwings-hybrid-builder'),
                'singular_name' => __('Service', 'authorwings-hybrid-builder'),
                'add_new' => __('Add Service', 'authorwings-hybrid-builder'),
                'add_new_item' => __('Add New Service', 'authorwings-hybrid-builder'),
                'edit_item' => __('Edit Service', 'authorwings-hybrid-builder'),
                'new_item' => __('New Service', 'authorwings-hybrid-builder'),
                'view_item' => __('View Service', 'authorwings-hybrid-builder'),
                'search_items' => __('Search Services', 'authorwings-hybrid-builder'),
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'awhb',
            'menu_position' => 26,
            'supports' => array('title','editor','page-attributes'),
            'capability_type' => 'post',
        ));
    }

    public static function metaboxes() {
        add_meta_box(
            'awhb_service_pricing',
            __('Pricing & Rules', 'authorwings-hybrid-builder'),
            array(__CLASS__, 'metabox_pricing'),
            self::POST_TYPE,
            'normal',
            'high'
        );
        add_meta_box(
            'awhb_service_options',
            __('Service Options', 'authorwings-hybrid-builder'),
            array(__CLASS__, 'metabox_options'),
            self::POST_TYPE,
            'normal',
            'default'
        );
    }

    public static function metabox_pricing($post) {
        wp_nonce_field('awhb_save_service', 'awhb_nonce');
        $meta = get_post_meta($post->ID, '_awhb_service', true);
        if (!is_array($meta)) $meta = array();

        $pricing_model = $meta['pricing_model'] ?? 'flat';
        $active = (int)($meta['active'] ?? 1);

        $fields = array(
            'active' => $active,
            'pricing_model' => $pricing_model,
            'base_price' => $meta['base_price'] ?? 0,
            'unit_price' => $meta['unit_price'] ?? 0,
            'min_charge' => $meta['min_charge'] ?? 0,
            'tier_basic' => $meta['tier_basic'] ?? 1,
            'tier_standard' => $meta['tier_standard'] ?? 1,
            'tier_premium' => $meta['tier_premium'] ?? 1,
        );
        ?>
        <style>
            .awhb-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
            .awhb-grid label{font-weight:600}
            .awhb-help{color:#666;font-size:12px;margin-top:4px}
            .awhb-row{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:12px}
        </style>

        <div class="awhb-grid">
            <div class="awhb-row">
                <label>
                    <input type="checkbox" name="awhb_service[active]" value="1" <?php checked($fields['active'], 1); ?> />
                    <?php esc_html_e('Active (visible on frontend)', 'authorwings-hybrid-builder'); ?>
                </label>
                <div class="awhb-help"><?php esc_html_e('Disable to hide without deleting.', 'authorwings-hybrid-builder'); ?></div>
            </div>

            <div class="awhb-row">
                <label for="awhb_pricing_model"><?php esc_html_e('Pricing Model', 'authorwings-hybrid-builder'); ?></label>
                <select id="awhb_pricing_model" name="awhb_service[pricing_model]" style="width:100%">
                    <option value="flat" <?php selected($fields['pricing_model'],'flat'); ?>><?php esc_html_e('Flat', 'authorwings-hybrid-builder'); ?></option>
                    <option value="per_word" <?php selected($fields['pricing_model'],'per_word'); ?>><?php esc_html_e('Per Word', 'authorwings-hybrid-builder'); ?></option>
                    <option value="per_page" <?php selected($fields['pricing_model'],'per_page'); ?>><?php esc_html_e('Per Page', 'authorwings-hybrid-builder'); ?></option>
                    <option value="per_item" <?php selected($fields['pricing_model'],'per_item'); ?>><?php esc_html_e('Per Item', 'authorwings-hybrid-builder'); ?></option>
                </select>
                <div class="awhb-help"><?php esc_html_e('Per Word uses Word Count, Per Page uses Page Count, Per Item uses Item Count.', 'authorwings-hybrid-builder'); ?></div>
            </div>

            <div class="awhb-row">
                <label><?php esc_html_e('Base Price', 'authorwings-hybrid-builder'); ?></label>
                <input type="number" step="0.01" min="0" name="awhb_service[base_price]" value="<?php echo esc_attr($fields['base_price']); ?>" style="width:100%" />
                <div class="awhb-help"><?php esc_html_e('Starting amount before unit pricing and options.', 'authorwings-hybrid-builder'); ?></div>
            </div>

            <div class="awhb-row">
                <label><?php esc_html_e('Unit Price', 'authorwings-hybrid-builder'); ?></label>
                <input type="number" step="0.0001" min="0" name="awhb_service[unit_price]" value="<?php echo esc_attr($fields['unit_price']); ?>" style="width:100%" />
                <div class="awhb-help"><?php esc_html_e('Rate per word/page/item when using a per-* model.', 'authorwings-hybrid-builder'); ?></div>
            </div>

            <div class="awhb-row">
                <label><?php esc_html_e('Minimum Charge', 'authorwings-hybrid-builder'); ?></label>
                <input type="number" step="0.01" min="0" name="awhb_service[min_charge]" value="<?php echo esc_attr($fields['min_charge']); ?>" style="width:100%" />
                <div class="awhb-help"><?php esc_html_e('If set, service total will never go below this.', 'authorwings-hybrid-builder'); ?></div>
            </div>

            <div class="awhb-row">
                <label><?php esc_html_e('Tier Multipliers', 'authorwings-hybrid-builder'); ?></label>
                <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px">
                    <div>
                        <div class="awhb-help" style="margin:0 0 4px"><?php esc_html_e('Basic', 'authorwings-hybrid-builder'); ?></div>
                        <input type="number" step="0.01" min="0" name="awhb_service[tier_basic]" value="<?php echo esc_attr($fields['tier_basic']); ?>" style="width:100%" />
                    </div>
                    <div>
                        <div class="awhb-help" style="margin:0 0 4px"><?php esc_html_e('Standard', 'authorwings-hybrid-builder'); ?></div>
                        <input type="number" step="0.01" min="0" name="awhb_service[tier_standard]" value="<?php echo esc_attr($fields['tier_standard']); ?>" style="width:100%" />
                    </div>
                    <div>
                        <div class="awhb-help" style="margin:0 0 4px"><?php esc_html_e('Premium', 'authorwings-hybrid-builder'); ?></div>
                        <input type="number" step="0.01" min="0" name="awhb_service[tier_premium]" value="<?php echo esc_attr($fields['tier_premium']); ?>" style="width:100%" />
                    </div>
                </div>
                <div class="awhb-help"><?php esc_html_e('Example: 1.00, 1.25, 1.60', 'authorwings-hybrid-builder'); ?></div>
            </div>
        </div>
        <?php
    }

    public static function metabox_options($post) {
        $meta = get_post_meta($post->ID, '_awhb_service', true);
        if (!is_array($meta)) $meta = array();
        $options = is_array($meta['options'] ?? null) ? $meta['options'] : array();

        wp_enqueue_script('awhb-admin-options', AWHB_URL . 'assets/admin-options.js', array('jquery'), AWHB_VERSION, true);
        wp_enqueue_style('awhb-admin', AWHB_URL . 'assets/admin.css', array(), AWHB_VERSION);

        $data = array(
            'options' => $options,
        );
        ?>
        <div id="awhb-options-root" data-options="<?php echo esc_attr(wp_json_encode($data)); ?>"></div>
        <p class="description"><?php esc_html_e('Add dropdown/radio/checkbox options with price deltas and optional multipliers.', 'authorwings-hybrid-builder'); ?></p>
        <?php
    }

    public static function save($post_id, $post) {
        if (!isset($_POST['awhb_nonce']) || !wp_verify_nonce($_POST['awhb_nonce'], 'awhb_save_service')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $raw = $_POST['awhb_service'] ?? array();
        if (!is_array($raw)) $raw = array();

        $meta = get_post_meta($post_id, '_awhb_service', true);
        if (!is_array($meta)) $meta = array();

        $meta['active'] = !empty($raw['active']) ? 1 : 0;
        $meta['pricing_model'] = Helpers::sanitize_pricing_model($raw['pricing_model'] ?? 'flat');
        $meta['base_price'] = isset($raw['base_price']) ? (float)$raw['base_price'] : 0;
        $meta['unit_price'] = isset($raw['unit_price']) ? (float)$raw['unit_price'] : 0;
        $meta['min_charge'] = isset($raw['min_charge']) ? (float)$raw['min_charge'] : 0;
        $meta['tier_basic'] = isset($raw['tier_basic']) ? (float)$raw['tier_basic'] : 1;
        $meta['tier_standard'] = isset($raw['tier_standard']) ? (float)$raw['tier_standard'] : 1;
        $meta['tier_premium'] = isset($raw['tier_premium']) ? (float)$raw['tier_premium'] : 1;

        // Options payload comes from admin JS
        if (isset($_POST['awhb_options_payload'])) {
            $payload = json_decode(wp_unslash($_POST['awhb_options_payload']), true);
            if (is_array($payload)) {
                $meta['options'] = self::sanitize_options($payload);
            }
        }

        update_post_meta($post_id, '_awhb_service', $meta);
    }

    private static function sanitize_options($options) {
        $out = array();
        foreach ($options as $opt) {
            if (!is_array($opt)) continue;
            $id = sanitize_key($opt['id'] ?? '');
            $label = sanitize_text_field($opt['label'] ?? '');
            $type = sanitize_key($opt['type'] ?? 'select');
            if (!$id || !$label) continue;
            if (!in_array($type, array('select','radio','checkbox'), true)) $type = 'select';

            $choices_out = array();
            $choices = is_array($opt['choices'] ?? null) ? $opt['choices'] : array();
            foreach ($choices as $ch) {
                if (!is_array($ch)) continue;
                $cid = sanitize_key($ch['id'] ?? '');
                $clabel = sanitize_text_field($ch['label'] ?? '');
                if (!$cid || !$clabel) continue;
                $choices_out[] = array(
                    'id' => $cid,
                    'label' => $clabel,
                    'price_delta' => isset($ch['price_delta']) ? (float)$ch['price_delta'] : 0,
                    'multiplier' => isset($ch['multiplier']) && $ch['multiplier'] !== '' ? (float)$ch['multiplier'] : '',
                );
            }

            $out[] = array(
                'id' => $id,
                'label' => $label,
                'type' => $type,
                'required' => !empty($opt['required']) ? 1 : 0,
                'choices' => $choices_out,
            );
        }
        return $out;
    }

    public static function cols($cols) {
        $cols['awhb_model'] = __('Model', 'authorwings-hybrid-builder');
        $cols['awhb_active'] = __('Active', 'authorwings-hybrid-builder');
        return $cols;
    }

    public static function col_render($col, $post_id) {
        $meta = get_post_meta($post_id, '_awhb_service', true);
        if (!is_array($meta)) $meta = array();
        if ($col === 'awhb_model') {
            echo esc_html($meta['pricing_model'] ?? 'flat');
        }
        if ($col === 'awhb_active') {
            echo !empty($meta['active']) ? 'Yes' : 'No';
        }
    }
}
