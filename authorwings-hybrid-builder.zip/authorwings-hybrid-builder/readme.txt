=== AuthorWings Hybrid Package Builder ===
Contributors: authorwings
Tags: calculator, package builder, publishing
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

A dashboard-controlled cost calculator + build-your-own-package for AuthorWings publishing services.

== Quick Start ==
1) Install and activate the plugin
2) Go to AuthorWings > Services
3) Add services and pricing rules (flat/per-word/per-page/per-item)
4) Add options (dropdown/radio/checkbox) with price deltas
5) Add the block “AuthorWings Hybrid Builder” to any page (or shortcode [authorwings_hybrid_builder])

== Notes ==
- Per Word uses Word Count
- Per Page uses Page Count
- Per Item uses Item Count
- Use “Minimum Charge” to prevent $0 totals for a service
