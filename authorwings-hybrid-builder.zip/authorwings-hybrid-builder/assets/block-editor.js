(function(wp){
  if(!wp || !wp.blocks || !wp.element) return;
  var el = wp.element.createElement;
  wp.blocks.registerBlockType('authorwings/hybrid-builder', {
    title: 'AuthorWings Hybrid Builder',
    icon: 'calculator',
    category: 'widgets',
    edit: function(){
      return el('div', {style:{padding:'12px', border:'1px dashed #cbd5e1', borderRadius:'12px'}},
        el('strong', null, 'AuthorWings Hybrid Builder'),
        el('div', {style:{marginTop:'6px', color:'#475569'}}, 'This block renders the calculator on the frontend.')
      );
    },
    save: function(){ return null; } // dynamic
  });
})(window.wp);
