(function($){
  function uid(prefix){
    prefix = prefix || 'opt';
    return (prefix + '_' + Math.random().toString(16).slice(2,10));
  }

  function parseData($root){
    try{
      var raw = $root.attr('data-options');
      if(!raw) return {options:[]};
      return JSON.parse(raw);
    }catch(e){ return {options:[]}; }
  }

  function render($root, state){
    $root.empty();

    var $wrap = $('<div/>');
    var $actions = $('<div class="awhb-actions"/>');
    var $add = $('<button type="button" class="awhb-adminBtn awhb-adminBtnPrimary">Add Option</button>');
    $actions.append($add);
    $wrap.append($actions);

    function addOption(){
      state.options.push({
        id: uid('opt'),
        label: '',
        type: 'select',
        required: 0,
        choices: [
          {id: uid('c'), label:'Option A', price_delta: 0, multiplier:''}
        ]
      });
      sync();
    }

    function addChoice(opt){
      opt.choices = opt.choices || [];
      opt.choices.push({id: uid('c'), label:'New Choice', price_delta:0, multiplier:''});
    }

    function removeOption(i){
      state.options.splice(i,1);
    }

    function removeChoice(opt, j){
      opt.choices.splice(j,1);
    }

    function sync(){
      $('#awhb_options_payload').val(JSON.stringify(state.options));
      render($root, state);
    }

    $add.on('click', addOption);

    if(!state.options.length){
      $wrap.append('<p class="awhb-adminSmall">No options yet. Click “Add Option”.</p>');
    }

    state.options.forEach(function(opt, i){
      var $card = $('<div class="awhb-adminCard"/>');
      var $row = $('<div class="awhb-adminRow"/>');

      var $id = $('<div/>').append('<label>Option ID</label>')
        .append('<input type="text" value="'+ (opt.id||'') +'" />');
      $id.find('input').on('input', function(){ opt.id = $(this).val().replace(/[^a-z0-9_]/gi,'').toLowerCase(); sync(); });

      var $label = $('<div/>').append('<label>Label</label>')
        .append('<input type="text" value="'+ (opt.label||'') +'" />');
      $label.find('input').on('input', function(){ opt.label = $(this).val(); $('#awhb_options_payload').val(JSON.stringify(state.options)); });

      var $type = $('<div/>').append('<label>Type</label>');
      var $sel = $('<select/>')
        .append('<option value="select">Dropdown</option>')
        .append('<option value="radio">Radio</option>')
        .append('<option value="checkbox">Checkbox</option>');
      $sel.val(opt.type||'select');
      $sel.on('change', function(){ opt.type = $(this).val(); sync(); });
      $type.append($sel);

      $row.append($id).append($label).append($type);

      var $req = $('<label style="display:inline-flex;gap:8px;align-items:center;margin-top:10px;font-weight:700;font-size:12px"><input type="checkbox" /> Required</label>');
      $req.find('input').prop('checked', !!opt.required).on('change', function(){ opt.required = this.checked ? 1 : 0; $('#awhb_options_payload').val(JSON.stringify(state.options)); });

      $card.append($row).append($req);

      var $table = $('<table class="awhb-choiceTable"><thead><tr><th>Choice ID</th><th>Label</th><th>Price Delta</th><th>Multiplier</th><th></th></tr></thead><tbody></tbody></table>');
      (opt.choices||[]).forEach(function(ch, j){
        var $tr = $('<tr/>');
        var $cid = $('<td/>').append('<input type="text" value="'+ (ch.id||'') +'" />');
        $cid.find('input').on('input', function(){ ch.id = $(this).val().replace(/[^a-z0-9_]/gi,'').toLowerCase(); $('#awhb_options_payload').val(JSON.stringify(state.options)); });

        var $cl = $('<td/>').append('<input type="text" value="'+ (ch.label||'') +'" />');
        $cl.find('input').on('input', function(){ ch.label = $(this).val(); $('#awhb_options_payload').val(JSON.stringify(state.options)); });

        var $pd = $('<td/>').append('<input type="number" step="0.01" value="'+ (ch.price_delta||0) +'" />');
        $pd.find('input').on('input', function(){ ch.price_delta = parseFloat($(this).val()||0); $('#awhb_options_payload').val(JSON.stringify(state.options)); });

        var $mul = $('<td/>').append('<input type="number" step="0.01" placeholder="Optional" value="'+ (ch.multiplier||'') +'" />');
        $mul.find('input').on('input', function(){ ch.multiplier = $(this).val(); $('#awhb_options_payload').val(JSON.stringify(state.options)); });

        var $rm = $('<td/>');
        var $rmBtn = $('<button type="button" class="awhb-adminBtn">Remove</button>');
        $rmBtn.on('click', function(){ removeChoice(opt, j); sync(); });
        $rm.append($rmBtn);

        $tr.append($cid).append($cl).append($pd).append($mul).append($rm);
        $table.find('tbody').append($tr);
      });

      var $btns = $('<div class="awhb-actions"/>');
      var $addChoiceBtn = $('<button type="button" class="awhb-adminBtn">Add Choice</button>');
      $addChoiceBtn.on('click', function(){ addChoice(opt); sync(); });
      var $rmOptBtn = $('<button type="button" class="awhb-adminBtn">Remove Option</button>');
      $rmOptBtn.on('click', function(){ removeOption(i); sync(); });

      $btns.append($addChoiceBtn).append($rmOptBtn);

      $card.append($table).append($btns);
      $wrap.append($card);
    });

    $root.append($wrap);

    // hidden field to store payload
    if(!$('#awhb_options_payload').length){
      $('<input type="hidden" id="awhb_options_payload" name="awhb_options_payload" />').appendTo($root.closest('form'));
    }
    $('#awhb_options_payload').val(JSON.stringify(state.options));
  }

  $(function(){
    var $root = $('#awhb-options-root');
    if(!$root.length) return;
    var state = parseData($root);
    state.options = state.options || [];
    render($root, state);
  });
})(jQuery);
