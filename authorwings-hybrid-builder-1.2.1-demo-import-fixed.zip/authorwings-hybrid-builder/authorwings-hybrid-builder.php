<?php
/**
 * Plugin Name: AuthorWings Hybrid Package Builder
 * Description: A dashboard-controlled cost calculator + build-your-own-package for AuthorWings publishing services. Manage services and pricing from WP Admin (no JSON editing).
 * Version: 1.2.1
 * Author: AuthorWings
 * License: GPLv2 or later
 * Text Domain: authorwings-hybrid-builder
 */

if (!defined('ABSPATH')) { exit; }

define('AWHB_VERSION', '1.2.1');
define('AWHB_PATH', plugin_dir_path(__FILE__));
define('AWHB_URL', plugin_dir_url(__FILE__));

require_once AWHB_PATH . 'includes/class-awhb-helpers.php';
require_once AWHB_PATH . 'includes/class-awhb-cpt.php';
require_once AWHB_PATH . 'includes/class-awhb-settings.php';
require_once AWHB_PATH . 'includes/class-awhb-rest.php';
require_once AWHB_PATH . 'includes/class-awhb-block.php';


// Activation: ensure defaults exist and show demo import notice if no services are present.
register_activation_hook(__FILE__, function() {
    if (!get_option('awhb_settings', null)) {
        add_option('awhb_settings', \AWHB\Helpers::get_settings());
    }
    $count = wp_count_posts(\AWHB\CPT::POST_TYPE);
    $published = isset($count->publish) ? (int)$count->publish : 0;
    if ($published === 0) {
        update_option('awhb_needs_demo_notice', 1);
    }
});

add_action('plugins_loaded', function() {
    \AWHB\CPT::init();
    \AWHB\Settings::init();
    \AWHB\REST::init();
    \AWHB\Block::init();
});
