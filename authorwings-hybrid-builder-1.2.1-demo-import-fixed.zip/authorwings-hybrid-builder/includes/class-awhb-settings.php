<?php
namespace AWHB;

if (!defined('ABSPATH')) { exit; }

final class Settings {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'register'));
        add_action('admin_notices', array(__CLASS__, 'maybe_notice_demo'));
        add_action('admin_post_awhb_import_demo', array(__CLASS__, 'handle_import_demo'));
        add_action('admin_post_awhb_remove_demo', array(__CLASS__, 'handle_remove_demo'));
    }

    public static function menu() {
        add_menu_page(
            __('AuthorWings Calculator', 'authorwings-hybrid-builder'),
            __('AuthorWings', 'authorwings-hybrid-builder'),
            'manage_options',
            'awhb',
            array(__CLASS__, 'page'),
            'dashicons-calculator',
            25
        );

        add_submenu_page('awhb', __('Settings', 'authorwings-hybrid-builder'), __('Settings', 'authorwings-hybrid-builder'), 'manage_options', 'awhb', array(__CLASS__, 'page'));
    }


    public static function register() {
        register_setting('awhb_settings_group', 'awhb_settings', array(
            'type' => 'array',
            'sanitize_callback' => array(__CLASS__, 'sanitize'),
            'default' => Helpers::get_settings(),
        ));

        add_settings_section('awhb_main', __('Global Settings', 'authorwings-hybrid-builder'), function() {
            echo '<p class="description">Control calculator defaults and quote routing.</p>';
        }, 'awhb');

        add_settings_field('currency_symbol', __('Currency Symbol', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_currency'), 'awhb', 'awhb_main');
        add_settings_field('default_word_count', __('Default Word Count', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_word'), 'awhb', 'awhb_main');
        add_settings_field('default_page_count', __('Default Page Count', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_page'), 'awhb', 'awhb_main');
        add_settings_field('default_item_count', __('Default Item Count', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_item'), 'awhb', 'awhb_main');
        add_settings_field('email_to', __('Quote Email To', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_email'), 'awhb', 'awhb_main');
        add_settings_field('require_phone', __('Require Phone', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_phone'), 'awhb', 'awhb_main');

        add_settings_section('awhb_demo', __('Demo Data', 'authorwings-hybrid-builder'), function() {
            echo '<p class="description">Import a ready-made set of book publishing + AI services to start faster. You can edit or delete them anytime.</p>';
        }, 'awhb');

        add_settings_field('demo_actions', __('Demo Actions', 'authorwings-hybrid-builder'), array(__CLASS__, 'field_demo_actions'), 'awhb', 'awhb_demo');

    }

    public static function sanitize($in) {
        $out = Helpers::get_settings();
        if (!is_array($in)) return $out;

        $out['currency_symbol'] = sanitize_text_field($in['currency_symbol'] ?? '$');
        $out['default_word_count'] = max(0, (int)($in['default_word_count'] ?? 50000));
        $out['default_page_count'] = max(0, (int)($in['default_page_count'] ?? 200));
        $out['default_item_count'] = max(0, (int)($in['default_item_count'] ?? 1));
        $out['email_to'] = sanitize_email($in['email_to'] ?? get_option('admin_email'));
        $out['require_phone'] = !empty($in['require_phone']) ? 1 : 0;

        return $out;
    }

    public static function page() {
        if (!current_user_can('manage_options')) return;
        wp_enqueue_style('awhb-admin', AWHB_URL . 'assets/admin.css', array(), AWHB_VERSION);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('AuthorWings Calculator Settings', 'authorwings-hybrid-builder'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('awhb_settings_group');
                do_settings_sections('awhb');
                submit_button();
                ?>
            </form>

            <hr/>
            <h2><?php esc_html_e('Use on Pages', 'authorwings-hybrid-builder'); ?></h2>
            <p>
                <?php esc_html_e('Add the “AuthorWings Hybrid Builder” block in Gutenberg, or use shortcode:', 'authorwings-hybrid-builder'); ?>
                <code>[authorwings_hybrid_builder]</code>
            </p>
        </div>
        <?php
    }

    public static function field_currency() {
        $s = Helpers::get_settings();
        printf('<input type="text" name="awhb_settings[currency_symbol]" value="%s" class="regular-text" />', esc_attr($s['currency_symbol']));
    }
    public static function field_word() {
        $s = Helpers::get_settings();
        printf('<input type="number" min="0" step="1" name="awhb_settings[default_word_count]" value="%s" />', esc_attr($s['default_word_count']));
    }
    public static function field_page() {
        $s = Helpers::get_settings();
        printf('<input type="number" min="0" step="1" name="awhb_settings[default_page_count]" value="%s" />', esc_attr($s['default_page_count']));
    }
    public static function field_item() {
        $s = Helpers::get_settings();
        printf('<input type="number" min="0" step="1" name="awhb_settings[default_item_count]" value="%s" />', esc_attr($s['default_item_count']));
    }
    public static function field_email() {
        $s = Helpers::get_settings();
        printf('<input type="email" name="awhb_settings[email_to]" value="%s" class="regular-text" />', esc_attr($s['email_to']));
    }
    public static function field_phone() {
        $s = Helpers::get_settings();
        printf('<label><input type="checkbox" name="awhb_settings[require_phone]" value="1" %s /> %s</label>',
            checked($s['require_phone'], 1, false),
            esc_html__('Require phone in quote form', 'authorwings-hybrid-builder')
        );
    }

    public static function field_demo_actions() {
        if (!current_user_can('manage_options')) { return; }

        $total = wp_count_posts(\AWHB\CPT::POST_TYPE);
        $published = isset($total->publish) ? (int)$total->publish : 0;

        $demo_q = new \WP_Query(array(
            'post_type' => \AWHB\CPT::POST_TYPE,
            'post_status' => 'any',
            'posts_per_page' => 1,
            'meta_key' => '_awhb_is_demo',
            'meta_value' => 1,
            'fields' => 'ids',
        ));
        $has_demo = $demo_q->have_posts();

        $import_url = wp_nonce_url(admin_url('admin-post.php?action=awhb_import_demo'), 'awhb_import_demo');
        $remove_url = wp_nonce_url(admin_url('admin-post.php?action=awhb_remove_demo'), 'awhb_remove_demo');

        echo '<div class="awhb-demo-actions">';
        echo '<p class="description">' . esc_html__('Tip: Import demo services once, then edit prices and options inside AuthorWings → Services.', 'authorwings-hybrid-builder') . '</p>';
        echo '<p><strong>' . esc_html__('Current services:', 'authorwings-hybrid-builder') . '</strong> ' . esc_html($published) . '</p>';

        echo '<p><a class="button button-secondary" href="' . esc_url($import_url) . '">' . esc_html__('Import Demo Services', 'authorwings-hybrid-builder') . '</a></p>';

        if ($has_demo) {
            echo '<p><a class="button button-link-delete" href="' . esc_url($remove_url) . '" onclick="return confirm(\'Remove demo services?\');">' . esc_html__('Remove Demo Services', 'authorwings-hybrid-builder') . '</a></p>';
        } else {
            echo '<p class="description">' . esc_html__('No demo services detected yet.', 'authorwings-hybrid-builder') . '</p>';
        }

        echo '</div>';
    }

    public static function maybe_notice_demo() {
        if (!current_user_can('manage_options')) { return; }
        if (!get_option('awhb_needs_demo_notice')) { return; }

        $count = wp_count_posts(\AWHB\CPT::POST_TYPE);
        $published = isset($count->publish) ? (int)$count->publish : 0;
        if ($published > 0) {
            delete_option('awhb_needs_demo_notice');
            return;
        }

        $import_url = wp_nonce_url(admin_url('admin-post.php?action=awhb_import_demo'), 'awhb_import_demo');
        echo '<div class="notice notice-info is-dismissible">';
        echo '<p><strong>' . esc_html__('AuthorWings:', 'authorwings-hybrid-builder') . '</strong> ' . esc_html__('Import demo book publishing + AI services to start fast.', 'authorwings-hybrid-builder') . '</p>';
        echo '<p><a class="button button-primary" href="' . esc_url($import_url) . '">' . esc_html__('Import Demo Services', 'authorwings-hybrid-builder') . '</a></p>';
        echo '</div>';
    }

    public static function handle_import_demo() {
        if (!current_user_can('manage_options')) { wp_die('Not allowed'); }
        check_admin_referer('awhb_import_demo');

        $count = wp_count_posts(\AWHB\CPT::POST_TYPE);
        $published = isset($count->publish) ? (int)$count->publish : 0;
        if ($published > 0) {
            delete_option('awhb_needs_demo_notice');
            wp_safe_redirect(admin_url('admin.php?page=awhb&awhb_msg=services_exist'));
            exit;
        }

        $demo = self::get_demo_dataset();
        foreach ($demo as $svc) {
            $post_id = wp_insert_post(array(
                'post_type' => \AWHB\CPT::POST_TYPE,
                'post_status' => 'publish',
                'post_title' => $svc['title'],
                'post_content' => $svc['content'],
                'menu_order' => (int)($svc['menu_order'] ?? 0),
            ));

            if (is_wp_error($post_id) || !$post_id) { continue; }

            update_post_meta($post_id, '_awhb_service', $svc['meta']);
            update_post_meta($post_id, '_awhb_is_demo', 1);
        }

        delete_option('awhb_needs_demo_notice');
        wp_safe_redirect(admin_url('admin.php?page=awhb&awhb_msg=demo_imported'));
        exit;
    }

    public static function handle_remove_demo() {
        if (!current_user_can('manage_options')) { wp_die('Not allowed'); }
        check_admin_referer('awhb_remove_demo');

        $q = new \WP_Query(array(
            'post_type' => \AWHB\CPT::POST_TYPE,
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_key' => '_awhb_is_demo',
            'meta_value' => 1,
        ));
        if ($q->have_posts()) {
            foreach ($q->posts as $pid) {
                wp_delete_post($pid, true);
            }
        }

        wp_safe_redirect(admin_url('admin.php?page=awhb&awhb_msg=demo_removed'));
        exit;
    }

    private static function get_demo_dataset() {
        return array(
    array(
        'title' => 'Manuscript Evaluation',
        'content' => 'High-level evaluation of your manuscript with actionable feedback.',
        'menu_order' => 1,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 249,
            'unit_price' => 0,
            'min_charge' => 249,
            'tier_basic' => 1.0,
            'tier_standard' => 1.25,
            'tier_premium' => 1.5,
            'options' => array(
                array(
                    'id' => 'turnaround',
                    'label' => 'Turnaround',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'standard',
                            'label' => 'Standard (10-14 days)',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'fast',
                            'label' => 'Fast (5-7 days)',
                            'price_delta' => 99,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'rush',
                            'label' => 'Rush (2-3 days)',
                            'price_delta' => 199,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'Developmental Editing',
        'content' => 'Structure, plot, pacing, and big-picture improvements.',
        'menu_order' => 2,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'per_word',
            'base_price' => 0,
            'unit_price' => 0.02,
            'min_charge' => 600,
            'tier_basic' => 1.0,
            'tier_standard' => 1.2,
            'tier_premium' => 1.45,
            'options' => array(
                array(
                    'id' => 'editor_level',
                    'label' => 'Editor Level',
                    'type' => 'radio',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'associate',
                            'label' => 'Associate',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'senior',
                            'label' => 'Senior',
                            'price_delta' => 0,
                            'multiplier' => 1.15
                        ),
                        array(
                            'id' => 'expert',
                            'label' => 'Expert',
                            'price_delta' => 0,
                            'multiplier' => 1.3
                        )
                    )
                ),
                array(
                    'id' => 'turnaround',
                    'label' => 'Turnaround',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'standard',
                            'label' => 'Standard',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'fast',
                            'label' => 'Fast',
                            'price_delta' => 250,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'rush',
                            'label' => 'Rush',
                            'price_delta' => 450,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'Copyediting',
        'content' => 'Grammar, clarity, consistency, and style refinement.',
        'menu_order' => 3,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'per_word',
            'base_price' => 0,
            'unit_price' => 0.012,
            'min_charge' => 350,
            'tier_basic' => 1.0,
            'tier_standard' => 1.2,
            'tier_premium' => 1.4,
            'options' => array(
                array(
                    'id' => 'style_guide',
                    'label' => 'Style Guide',
                    'type' => 'select',
                    'required' => 0,
                    'choices' => array(
                        array(
                            'id' => 'none',
                            'label' => 'Use my manuscript style',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'cmos',
                            'label' => 'Chicago Manual of Style alignment',
                            'price_delta' => 75,
                            'multiplier' => ''
                        )
                    )
                ),
                array(
                    'id' => 'turnaround',
                    'label' => 'Turnaround',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'standard',
                            'label' => 'Standard',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'fast',
                            'label' => 'Fast',
                            'price_delta' => 150,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'rush',
                            'label' => 'Rush',
                            'price_delta' => 300,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'Proofreading',
        'content' => 'Final polish to catch typos, formatting issues, and minor inconsistencies.',
        'menu_order' => 4,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'per_word',
            'base_price' => 0,
            'unit_price' => 0.006,
            'min_charge' => 200,
            'tier_basic' => 1.0,
            'tier_standard' => 1.2,
            'tier_premium' => 1.35,
            'options' => array(
                array(
                    'id' => 'turnaround',
                    'label' => 'Turnaround',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'standard',
                            'label' => 'Standard',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'fast',
                            'label' => 'Fast',
                            'price_delta' => 100,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'rush',
                            'label' => 'Rush',
                            'price_delta' => 200,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'Formatting and Layout',
        'content' => 'Professional interior formatting for print and ebook.',
        'menu_order' => 5,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'per_page',
            'base_price' => 99,
            'unit_price' => 2.0,
            'min_charge' => 299,
            'tier_basic' => 1.0,
            'tier_standard' => 1.15,
            'tier_premium' => 1.3,
            'options' => array(
                array(
                    'id' => 'deliverables',
                    'label' => 'Deliverables',
                    'type' => 'radio',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'ebook',
                            'label' => 'Ebook (EPUB)',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'print',
                            'label' => 'Print (PDF)',
                            'price_delta' => 50,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'both',
                            'label' => 'Both (EPUB + PDF)',
                            'price_delta' => 120,
                            'multiplier' => ''
                        )
                    )
                ),
                array(
                    'id' => 'complex_layout',
                    'label' => 'Complex Layout',
                    'type' => 'checkbox',
                    'required' => 0,
                    'choices' => array(
                        array(
                            'id' => 'tables',
                            'label' => 'Tables / Figures heavy',
                            'price_delta' => 150,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'images',
                            'label' => 'Image placement heavy',
                            'price_delta' => 200,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'Cover Design',
        'content' => 'Custom cover design aligned with your genre and market expectations.',
        'menu_order' => 6,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 399,
            'unit_price' => 0,
            'min_charge' => 399,
            'tier_basic' => 1.0,
            'tier_standard' => 1.25,
            'tier_premium' => 1.6,
            'options' => array(
                array(
                    'id' => 'concepts',
                    'label' => 'Concepts',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => '1',
                            'label' => '1 concept',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '2',
                            'label' => '2 concepts',
                            'price_delta' => 120,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '3',
                            'label' => '3 concepts',
                            'price_delta' => 220,
                            'multiplier' => ''
                        )
                    )
                ),
                array(
                    'id' => 'revisions',
                    'label' => 'Revisions',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => '2',
                            'label' => '2 revisions',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '4',
                            'label' => '4 revisions',
                            'price_delta' => 80,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '6',
                            'label' => '6 revisions',
                            'price_delta' => 160,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'ISBN and Imprint Setup',
        'content' => 'ISBN allocation guidance and imprint setup support.',
        'menu_order' => 7,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'per_item',
            'base_price' => 49,
            'unit_price' => 79,
            'min_charge' => 128,
            'tier_basic' => 1.0,
            'tier_standard' => 1.15,
            'tier_premium' => 1.3,
            'options' => array(
                array(
                    'id' => 'bundle',
                    'label' => 'Bundle',
                    'type' => 'radio',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => '1',
                            'label' => '1 ISBN',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '10',
                            'label' => '10 ISBN bundle',
                            'price_delta' => 399,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'KDP Setup and Metadata',
        'content' => 'Amazon KDP listing setup, metadata, and upload support.',
        'menu_order' => 8,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 199,
            'unit_price' => 0,
            'min_charge' => 199,
            'tier_basic' => 1.0,
            'tier_standard' => 1.2,
            'tier_premium' => 1.4,
            'options' => array(
                array(
                    'id' => 'a_plus',
                    'label' => 'A+ Content',
                    'type' => 'checkbox',
                    'required' => 0,
                    'choices' => array(
                        array(
                            'id' => 'basic',
                            'label' => 'Basic A+ layout',
                            'price_delta' => 149,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'IngramSpark Setup',
        'content' => 'IngramSpark distribution setup and file checks.',
        'menu_order' => 9,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 249,
            'unit_price' => 0,
            'min_charge' => 249,
            'tier_basic' => 1.0,
            'tier_standard' => 1.2,
            'tier_premium' => 1.45,
            'options' => array(
                array(
                    'id' => 'hardcover',
                    'label' => 'Hardcover add-on',
                    'type' => 'checkbox',
                    'required' => 0,
                    'choices' => array(
                        array(
                            'id' => 'hc',
                            'label' => 'Enable Hardcover setup',
                            'price_delta' => 99,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'Keyword and Category Research',
        'content' => 'Market-aligned keyword and BISAC/category research for discoverability.',
        'menu_order' => 10,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 149,
            'unit_price' => 0,
            'min_charge' => 149,
            'tier_basic' => 1.0,
            'tier_standard' => 1.25,
            'tier_premium' => 1.5,
            'options' => array(
                array(
                    'id' => 'depth',
                    'label' => 'Depth',
                    'type' => 'radio',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => 'standard',
                            'label' => 'Standard',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => 'advanced',
                            'label' => 'Advanced (competitor mapping)',
                            'price_delta' => 129,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'AI Title and Subtitle Pack',
        'content' => 'AI-assisted title, subtitle, and positioning variants with human curation.',
        'menu_order' => 11,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 79,
            'unit_price' => 0,
            'min_charge' => 79,
            'tier_basic' => 1.0,
            'tier_standard' => 1.25,
            'tier_premium' => 1.6,
            'options' => array(
                array(
                    'id' => 'variants',
                    'label' => 'Number of Variants',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => '25',
                            'label' => '25 options',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '50',
                            'label' => '50 options',
                            'price_delta' => 49,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '100',
                            'label' => '100 options',
                            'price_delta' => 99,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    ),
    array(
        'title' => 'AI Book Outline Builder',
        'content' => 'AI-assisted outline with chapter breakdown and key beats.',
        'menu_order' => 12,
        'meta' => array(
            'active' => 1,
            'pricing_model' => 'flat',
            'base_price' => 129,
            'unit_price' => 0,
            'min_charge' => 129,
            'tier_basic' => 1.0,
            'tier_standard' => 1.25,
            'tier_premium' => 1.55,
            'options' => array(
                array(
                    'id' => 'chapters',
                    'label' => 'Outline Size',
                    'type' => 'select',
                    'required' => 1,
                    'choices' => array(
                        array(
                            'id' => '10',
                            'label' => 'Up to 10 chapters',
                            'price_delta' => 0,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '20',
                            'label' => 'Up to 20 chapters',
                            'price_delta' => 79,
                            'multiplier' => ''
                        ),
                        array(
                            'id' => '30',
                            'label' => 'Up to 30 chapters',
                            'price_delta' => 139,
                            'multiplier' => ''
                        )
                    )
                )
            )
        )
    )
);
    }

}
