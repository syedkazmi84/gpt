<?php
namespace AWHB;

if (!defined('ABSPATH')) { exit; }

final class Helpers {

    public static function sanitize_pricing_model($model) {
        $allowed = array('flat','per_word','per_page','per_item');
        return in_array($model, $allowed, true) ? $model : 'flat';
    }

    public static function money($amount, $currency_symbol) {
        $n = is_numeric($amount) ? (float)$amount : 0.0;
        return $currency_symbol . number_format($n, 2, '.', ',');
    }

    public static function get_settings() {
        $defaults = array(
            'currency_symbol' => '$',
            'default_word_count' => 50000,
            'default_page_count' => 200,
            'default_item_count' => 1,
            'email_to' => get_option('admin_email'),
            'require_phone' => 0,
        );
        $saved = get_option('awhb_settings', array());
        return wp_parse_args($saved, $defaults);
    }

    public static function get_services() {
        $posts = get_posts(array(
            'post_type' => CPT::POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'menu_order',
            'order' => 'ASC',
        ));

        $services = array();
        foreach ($posts as $p) {
            $meta = get_post_meta($p->ID, '_awhb_service', true);
            if (!is_array($meta)) { $meta = array(); }

            $pricing_model = self::sanitize_pricing_model($meta['pricing_model'] ?? 'flat');
            $service = array(
                'id' => (int)$p->ID,
                'slug' => $p->post_name,
                'title' => get_the_title($p),
                'description' => wp_kses_post($p->post_content),
                'active' => (int)($meta['active'] ?? 1),
                'pricing' => array(
                    'model' => $pricing_model,
                    'base' => (float)($meta['base_price'] ?? 0),
                    'unit_price' => (float)($meta['unit_price'] ?? 0),
                    'min_charge' => (float)($meta['min_charge'] ?? 0),
                ),
                'tiers' => array(
                    'basic' => (float)($meta['tier_basic'] ?? 1),
                    'standard' => (float)($meta['tier_standard'] ?? 1),
                    'premium' => (float)($meta['tier_premium'] ?? 1),
                ),
                'options' => is_array($meta['options'] ?? null) ? $meta['options'] : array(),
            );

            $services[] = $service;
        }
        return $services;
    }

    public static function compute_service_total($service, $tier_key, $qtys, $selected_options) {
        $pricing = $service['pricing'];
        $model = $pricing['model'];
        $base = (float)$pricing['base'];
        $unit = (float)$pricing['unit_price'];
        $min = (float)$pricing['min_charge'];

        $qty = 0;
        if ($model === 'per_word') $qty = (int)($qtys['word_count'] ?? 0);
        if ($model === 'per_page') $qty = (int)($qtys['page_count'] ?? 0);
        if ($model === 'per_item') $qty = (int)($qtys['item_count'] ?? 0);

        $line = $base;
        if ($model !== 'flat') {
            $line += max(0, $qty) * $unit;
        }

        // apply option deltas
        if (!empty($service['options']) && is_array($service['options'])) {
            foreach ($service['options'] as $opt) {
                $opt_id = $opt['id'] ?? '';
                if (!$opt_id) continue;

                $val = $selected_options[$opt_id] ?? null;
                if ($val === null || $val === '') continue;

                $type = $opt['type'] ?? 'select';
                $choices = is_array($opt['choices'] ?? null) ? $opt['choices'] : array();

                if ($type === 'checkbox') {
                    // val can be array of checked ids
                    $vals = is_array($val) ? $val : array($val);
                    foreach ($choices as $ch) {
                        $cid = $ch['id'] ?? '';
                        if (!$cid) continue;
                        if (!in_array($cid, $vals, true)) continue;
                        $line += (float)($ch['price_delta'] ?? 0);
                        if (!empty($ch['multiplier'])) $line *= (float)$ch['multiplier'];
                    }
                } else {
                    foreach ($choices as $ch) {
                        if (($ch['id'] ?? '') === $val) {
                            $line += (float)($ch['price_delta'] ?? 0);
                            if (!empty($ch['multiplier'])) $line *= (float)$ch['multiplier'];
                            break;
                        }
                    }
                }
            }
        }

        // tier multiplier
        $tier_key = in_array($tier_key, array('basic','standard','premium'), true) ? $tier_key : 'standard';
        $mult = (float)($service['tiers'][$tier_key] ?? 1);
        if ($mult <= 0) $mult = 1;
        $line *= $mult;

        if ($min > 0) $line = max($min, $line);

        return max(0, round($line, 2));
    }


    public static function insert_demo_services($overwrite = false) {
        $existing = get_posts(array(
            'post_type' => CPT::POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => 1,
        ));
        if (!$overwrite && !empty($existing)) {
            return array('inserted' => 0, 'skipped' => 1);
        }

        $services = self::demo_services_dataset();
        $inserted = 0;
        $order = 0;

        foreach ($services as $s) {
            $order++;

            $post_id = wp_insert_post(array(
                'post_type' => CPT::POST_TYPE,
                'post_status' => 'publish',
                'post_title' => $s['title'],
                'post_content' => $s['description'],
                'menu_order' => $order,
            ), true);

            if (is_wp_error($post_id) || !$post_id) continue;

            $meta = array(
                'active' => 1,
                'pricing_model' => $s['pricing_model'],
                'base_price' => (float)$s['base_price'],
                'unit_price' => (float)$s['unit_price'],
                'min_charge' => (float)$s['min_charge'],
                'tier_basic' => (float)$s['tier_basic'],
                'tier_standard' => (float)$s['tier_standard'],
                'tier_premium' => (float)$s['tier_premium'],
                'options' => $s['options'],
                'is_demo' => 1,
            );

            update_post_meta($post_id, '_awhb_service', $meta);
            update_post_meta($post_id, '_awhb_demo', 1);
            $inserted++;
        }

        return array('inserted' => $inserted, 'skipped' => 0);
    }

    public static function remove_demo_services() {
        $posts = get_posts(array(
            'post_type' => CPT::POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => -1,
            'meta_key' => '_awhb_demo',
            'meta_value' => '1',
        ));
        $removed = 0;
        foreach ($posts as $p) {
            wp_delete_post($p->ID, true);
            $removed++;
        }
        return $removed;
    }

    private static function demo_services_dataset() {
        // Pricing numbers are demo defaults only. Adjust any service after import.
        $tier_basic = 1.0;
        $tier_standard = 1.25;
        $tier_premium = 1.5;

        $turnaround = array(
            'id' => 'turnaround',
            'label' => 'Turnaround',
            'type' => 'select',
            'required' => 1,
            'choices' => array(
                array('id' => 'standard', 'label' => 'Standard', 'price_delta' => 0, 'multiplier' => ''),
                array('id' => 'fast', 'label' => 'Fast', 'price_delta' => 150, 'multiplier' => ''),
                array('id' => 'rush', 'label' => 'Rush', 'price_delta' => 300, 'multiplier' => ''),
            ),
        );

        $delivery = array(
            'id' => 'deliverables',
            'label' => 'Deliverables',
            'type' => 'select',
            'required' => 1,
            'choices' => array(
                array('id' => 'ebook', 'label' => 'eBook', 'price_delta' => 0, 'multiplier' => ''),
                array('id' => 'print', 'label' => 'Print', 'price_delta' => 75, 'multiplier' => ''),
                array('id' => 'both', 'label' => 'eBook + Print', 'price_delta' => 150, 'multiplier' => ''),
            ),
        );

        $revisions = array(
            'id' => 'revisions',
            'label' => 'Revisions',
            'type' => 'select',
            'required' => 1,
            'choices' => array(
                array('id' => '1', 'label' => '1 Round', 'price_delta' => 0, 'multiplier' => ''),
                array('id' => '2', 'label' => '2 Rounds', 'price_delta' => 120, 'multiplier' => ''),
                array('id' => '3', 'label' => '3 Rounds', 'price_delta' => 220, 'multiplier' => ''),
            ),
        );

        $editor_level = array(
            'id' => 'editor_level',
            'label' => 'Specialist Level',
            'type' => 'select',
            'required' => 1,
            'choices' => array(
                array('id' => 'associate', 'label' => 'Associate', 'price_delta' => 0, 'multiplier' => '1'),
                array('id' => 'senior', 'label' => 'Senior', 'price_delta' => 0, 'multiplier' => '1.15'),
                array('id' => 'expert', 'label' => 'Expert', 'price_delta' => 0, 'multiplier' => '1.3'),
            ),
        );

        $services = array(
            array(
                'title' => 'Manuscript Evaluation',
                'description' => 'High-level evaluation with actionable notes, strengths, and improvement roadmap.',
                'pricing_model' => 'flat',
                'base_price' => 249,
                'unit_price' => 0,
                'min_charge' => 249,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround),
            ),
            array(
                'title' => 'Developmental Editing',
                'description' => 'Big-picture structure, clarity, pacing, and chapter-level guidance.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.018,
                'min_charge' => 350,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround, $editor_level),
            ),
            array(
                'title' => 'Line Editing',
                'description' => 'Style, flow, voice consistency, and sentence-level refinement.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.014,
                'min_charge' => 300,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround, $editor_level),
            ),
            array(
                'title' => 'Copyediting',
                'description' => 'Grammar, consistency, and professional polish for publication readiness.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.010,
                'min_charge' => 250,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround, $editor_level),
            ),
            array(
                'title' => 'Proofreading',
                'description' => 'Final quality check for typos, spacing, and formatting issues.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.006,
                'min_charge' => 175,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround),
            ),
            array(
                'title' => 'Formatting and Layout',
                'description' => 'Professional interior formatting for platform-ready distribution.',
                'pricing_model' => 'per_page',
                'base_price' => 99,
                'unit_price' => 1.25,
                'min_charge' => 199,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($delivery, $turnaround),
            ),
            array(
                'title' => 'Cover Design',
                'description' => 'Market-aligned cover design with concept and revision rounds.',
                'pricing_model' => 'flat',
                'base_price' => 499,
                'unit_price' => 0,
                'min_charge' => 499,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($revisions, $turnaround),
            ),
            array(
                'title' => 'ISBN and Imprint Setup',
                'description' => 'ISBN acquisition support and imprint setup guidance.',
                'pricing_model' => 'per_item',
                'base_price' => 79,
                'unit_price' => 49,
                'min_charge' => 79,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array(
                    array(
                        'id' => 'isbn_bundle',
                        'label' => 'ISBN Bundle',
                        'type' => 'select',
                        'required' => 1,
                        'choices' => array(
                            array('id' => 'single', 'label' => 'Single ISBN', 'price_delta' => 0, 'multiplier' => ''),
                            array('id' => 'ten', 'label' => '10 ISBN Bundle', 'price_delta' => 299, 'multiplier' => ''),
                        ),
                    ),
                ),
            ),
            array(
                'title' => 'KDP Setup and Metadata',
                'description' => 'KDP account setup, listing configuration, metadata, and upload support.',
                'pricing_model' => 'flat',
                'base_price' => 199,
                'unit_price' => 0,
                'min_charge' => 199,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround),
            ),
            array(
                'title' => 'IngramSpark Setup',
                'description' => 'IngramSpark setup for expanded distribution and print channels.',
                'pricing_model' => 'flat',
                'base_price' => 249,
                'unit_price' => 0,
                'min_charge' => 249,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($turnaround),
            ),
            array(
                'title' => 'Book Description and Blurb',
                'description' => 'Conversion-focused blurb written for your genre and audience.',
                'pricing_model' => 'flat',
                'base_price' => 149,
                'unit_price' => 0,
                'min_charge' => 149,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($revisions),
            ),
            array(
                'title' => 'Keyword and Category Research',
                'description' => 'Research-backed keywords and categories for stronger discoverability.',
                'pricing_model' => 'flat',
                'base_price' => 149,
                'unit_price' => 0,
                'min_charge' => 149,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array(),
            ),
            array(
                'title' => 'Launch Plan',
                'description' => 'A practical launch timeline with checklist, assets, and channel plan.',
                'pricing_model' => 'flat',
                'base_price' => 299,
                'unit_price' => 0,
                'min_charge' => 299,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array(),
            ),
            array(
                'title' => 'Social Media Kit',
                'description' => 'Branded promo kit: post templates, captions, and CTA prompts.',
                'pricing_model' => 'flat',
                'base_price' => 199,
                'unit_price' => 0,
                'min_charge' => 199,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array($revisions),
            ),
            array(
                'title' => 'Ghostwriting',
                'description' => 'Professional ghostwriting support. Demo rate shown, customize per project.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.08,
                'min_charge' => 2500,
                'tier_basic' => $tier_basic,
                'tier_standard' => $tier_standard,
                'tier_premium' => $tier_premium,
                'options' => array(
                    array(
                        'id' => 'research_depth',
                        'label' => 'Research Depth',
                        'type' => 'select',
                        'required' => 1,
                        'choices' => array(
                            array('id' => 'light', 'label' => 'Light', 'price_delta' => 0, 'multiplier' => ''),
                            array('id' => 'standard', 'label' => 'Standard', 'price_delta' => 500, 'multiplier' => ''),
                            array('id' => 'deep', 'label' => 'Deep', 'price_delta' => 1200, 'multiplier' => ''),
                        ),
                    ),
                ),
            ),

            // AI services (flat demo pricing)
            array(
                'title' => 'AI Title and Subtitle Pack',
                'description' => 'AI-assisted title ideas refined into a shortlist aligned to your genre.',
                'pricing_model' => 'flat',
                'base_price' => 79,
                'unit_price' => 0,
                'min_charge' => 79,
                'tier_basic' => 1,
                'tier_standard' => 1,
                'tier_premium' => 1,
                'options' => array($revisions),
            ),
            array(
                'title' => 'AI Book Outline Builder',
                'description' => 'AI-assisted outline with chapter beats, sections, and consistency checks.',
                'pricing_model' => 'flat',
                'base_price' => 129,
                'unit_price' => 0,
                'min_charge' => 129,
                'tier_basic' => 1,
                'tier_standard' => 1,
                'tier_premium' => 1,
                'options' => array($revisions),
            ),
            array(
                'title' => 'AI Blurb Variations',
                'description' => 'Multiple blurb variations for testing, refined for clarity and hooks.',
                'pricing_model' => 'flat',
                'base_price' => 69,
                'unit_price' => 0,
                'min_charge' => 69,
                'tier_basic' => 1,
                'tier_standard' => 1,
                'tier_premium' => 1,
                'options' => array($revisions),
            ),
            array(
                'title' => 'AI Ad Copy Pack',
                'description' => 'AI-assisted ad copy variations for Amazon/Meta/Google creatives.',
                'pricing_model' => 'flat',
                'base_price' => 99,
                'unit_price' => 0,
                'min_charge' => 99,
                'tier_basic' => 1,
                'tier_standard' => 1,
                'tier_premium' => 1,
                'options' => array(),
            ),
            array(
                'title' => 'AI Consistency Check',
                'description' => 'AI consistency pass for names, timeline, and repeated facts.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.002,
                'min_charge' => 49,
                'tier_basic' => 1,
                'tier_standard' => 1,
                'tier_premium' => 1,
                'options' => array(),
            ),
            array(
                'title' => 'AI Proof Pass + Human Review',
                'description' => 'AI proof pass plus human spot-check review for high-confidence delivery.',
                'pricing_model' => 'per_word',
                'base_price' => 0,
                'unit_price' => 0.004,
                'min_charge' => 79,
                'tier_basic' => 1,
                'tier_standard' => 1,
                'tier_premium' => 1,
                'options' => array($turnaround),
            ),
        );

        return $services;
    }

}
