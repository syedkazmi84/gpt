(function(){
  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function el(tag, attrs){
    var n=document.createElement(tag);
    if(attrs){ Object.keys(attrs).forEach(function(k){
      if(k==='text') n.textContent=attrs[k];
      else if(k==='html') n.innerHTML=attrs[k];
      else if(k==='class') n.className=attrs[k];
      else n.setAttribute(k, attrs[k]);
    });}
    return n;
  }

  function money(n, sym){
    n = isFinite(n) ? Number(n) : 0;
    return (sym||'$') + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  function fetchConfig(){
    return fetch((window.AWHB ? window.AWHB.restUrl : '/wp-json/authorwings/v1') + '/config', {credentials:'same-origin'})
      .then(function(r){ return r.json(); });
  }

  function computeLine(service, tier, qtys, selectedOptions){
    var p=service.pricing||{};
    var model=p.model||'flat';
    var base=Number(p.base||0);
    var unit=Number(p.unit_price||0);
    var min=Number(p.min_charge||0);
    var qty=0;
    if(model==='per_word') qty = Number(qtys.word_count||0);
    if(model==='per_page') qty = Number(qtys.page_count||0);
    if(model==='per_item') qty = Number(qtys.item_count||0);

    var line=base;
    if(model!=='flat'){ line += Math.max(0, qty) * unit; }

    // options
    (service.options||[]).forEach(function(opt){
      var oid=opt.id;
      if(!oid) return;
      var val = selectedOptions[oid];
      if(val==null || val==='') return;
      var type = opt.type || 'select';
      var choices = opt.choices || [];
      if(type==='checkbox'){
        var vals = Array.isArray(val) ? val : [val];
        choices.forEach(function(ch){
          if(vals.indexOf(ch.id)===-1) return;
          line += Number(ch.price_delta||0);
          if(ch.multiplier) line *= Number(ch.multiplier||1);
        });
      } else {
        for(var i=0;i<choices.length;i++){
          var ch=choices[i];
          if(ch.id===val){
            line += Number(ch.price_delta||0);
            if(ch.multiplier) line *= Number(ch.multiplier||1);
            break;
          }
        }
      }
    });

    var tiers = service.tiers || {};
    var mult = Number(tiers[tier] || 1);
    if(!isFinite(mult) || mult<=0) mult=1;
    line *= mult;

    if(min>0) line = Math.max(min, line);
    line = Math.max(0, Math.round(line*100)/100);
    return line;
  }

  function mount(root, cfg){
    var settings = cfg.settings||{};
    var services = (cfg.services||[]).filter(function(s){ return s.active; });

    var state = {
      tier: 'standard',
      word_count: Number(settings.default_word_count||50000),
      page_count: Number(settings.default_page_count||200),
      item_count: Number(settings.default_item_count||1),
      selected: {},        // serviceId => true
      options: {},         // serviceId => {optId: val}
    };

    var header = el('div', {class:'awhb__header'});
    header.appendChild(el('div', {class:'awhb__title', text:'Build Your Publishing Package'}));
    header.appendChild(el('div', {class:'awhb__subtitle', text:'Select services, adjust quantities, and get an instant estimate.'}));

    var controls = el('div', {class:'awhb__controls'});
    // tier select
    var tierBox = el('div', {class:'awhb__field'});
    tierBox.appendChild(el('label', {text:'Tier'}));
    var tierSel = el('select');
    [['basic','Basic'],['standard','Standard'],['premium','Premium']].forEach(function(t){
      var o=el('option'); o.value=t[0]; o.textContent=t[1]; tierSel.appendChild(o);
    });
    tierSel.value = state.tier;
    tierSel.addEventListener('change', function(){ state.tier=this.value; renderTotals(); });
    tierBox.appendChild(tierSel);

    function qtyField(label, key){
      var box=el('div', {class:'awhb__field'});
      box.appendChild(el('label', {text: label}));
      var inp=el('input'); inp.type='number'; inp.min='0'; inp.step='1'; inp.value=String(state[key]);
      inp.addEventListener('input', function(){ state[key]=Number(this.value||0); renderTotals(); });
      box.appendChild(inp);
      return box;
    }

    controls.appendChild(tierBox);
    controls.appendChild(qtyField('Word Count', 'word_count'));
    controls.appendChild(qtyField('Page Count', 'page_count'));
    controls.appendChild(qtyField('Item Count', 'item_count'));

    var grid = el('div', {class:'awhb__grid'});

    var summary = el('div', {class:'awhb__summary'});
    var totalLine = el('div', {class:'awhb__total'});
    var totalLabel = el('div', {class:'awhb__totalLabel', text:'Estimated Total'});
    var totalValue = el('div', {class:'awhb__totalValue', text: money(0, settings.currency_symbol)});
    totalLine.appendChild(totalLabel);
    totalLine.appendChild(totalValue);

    var selectedList = el('div', {class:'awhb__selected'});
    var actions = el('div', {class:'awhb__actions'});
    var btn = el('button', {class:'awhb__btn', type:'button', text:'Request a Quote'});
    actions.appendChild(btn);

    summary.appendChild(totalLine);
    summary.appendChild(el('div', {class:'awhb__hr'}));
    summary.appendChild(el('div', {class:'awhb__sectionTitle', text:'Selected Services'}));
    summary.appendChild(selectedList);
    summary.appendChild(actions);

    // modal
    var modal = el('div', {class:'awhb__modal', hidden:'hidden'});
    modal.innerHTML = '<div class="awhb__modalBackdrop" data-awhb-close="1"></div>\
      <div class="awhb__modalCard" role="dialog" aria-modal="true">\
        <button class="awhb__modalClose" type="button" data-awhb-close="1">×</button>\
        <div class="awhb__modalTitle">Request a Quote</div>\
        <div class="awhb__modalSub">Submit your details and we will contact you shortly.</div>\
        <form class="awhb__form">\
          <div class="awhb__formGrid">\
            <div class="awhb__field"><label>Name</label><input name="name" required /></div>\
            <div class="awhb__field"><label>Email</label><input name="email" type="email" required /></div>\
            <div class="awhb__field"><label>Phone</label><input name="phone" /></div>\
            <div class="awhb__field awhb__fieldFull"><label>Notes</label><textarea name="notes" rows="4"></textarea></div>\
          </div>\
          <div class="awhb__formActions">\
            <button type="button" class="awhb__btnGhost" data-awhb-close="1">Cancel</button>\
            <button type="submit" class="awhb__btn">Submit Request</button>\
          </div>\
          <div class="awhb__formMsg" aria-live="polite"></div>\
        </form>\
      </div>';

    function openModal(){ modal.hidden=false; }
    function closeModal(){ modal.hidden=true; }
    qsa('[data-awhb-close="1"]', modal).forEach(function(x){ x.addEventListener('click', closeModal); });
    btn.addEventListener('click', function(){ openModal(); });

    // submit quote
    qs('form', modal).addEventListener('submit', function(e){
      e.preventDefault();
      var form = e.currentTarget;
      var msg = qs('.awhb__formMsg', modal);
      msg.textContent = '';
      var fd = new FormData(form);
      var name = (fd.get('name')||'').toString().trim();
      var email = (fd.get('email')||'').toString().trim();
      if(!name || !email){ msg.textContent='Please provide a valid name and email.'; return; }

      var payload = buildPayload();
      var body = {
        name: name,
        email: email,
        phone: (fd.get('phone')||'').toString().trim(),
        notes: (fd.get('notes')||'').toString().trim(),
        payload: payload
      };

      fetch((window.AWHB ? window.AWHB.restUrl : '/wp-json/authorwings/v1') + '/quote', {
        method:'POST',
        credentials:'same-origin',
        headers:{
          'Content-Type':'application/json'
        },
        body: JSON.stringify(body)
      }).then(function(r){
        if(!r.ok) return r.json().then(function(j){ throw (j && j.message) ? j.message : 'Request failed.'; });
        return r.json();
      }).then(function(){
        msg.textContent='Request submitted. We will contact you shortly.';
        form.reset();
        setTimeout(closeModal, 700);
      }).catch(function(err){
        msg.textContent = (typeof err==='string') ? err : 'Request failed. Please try again.';
      });
    });

    function serviceCard(service){
      var card = el('div', {class:'awhb__card'});
      var top = el('div', {class:'awhb__cardTop'});
      var left = el('div');
      left.appendChild(el('div', {class:'awhb__cardTitle', text: service.title}));
      if(service.description){
        left.appendChild(el('div', {class:'awhb__cardDesc', html: service.description}));
      }
      var right = el('div', {class:'awhb__cardRight'});
      var toggle = el('label', {class:'awhb__toggle'});
      var cb = el('input'); cb.type='checkbox';
      cb.addEventListener('change', function(){
        state.selected[service.id] = cb.checked;
        // auto defaults to avoid $0 confusion
        var model = (service.pricing||{}).model;
        if(cb.checked){
          if(model==='per_word' && !state.word_count) state.word_count = Number(settings.default_word_count||50000);
          if(model==='per_page' && !state.page_count) state.page_count = Number(settings.default_page_count||200);
          if(model==='per_item' && !state.item_count) state.item_count = Number(settings.default_item_count||1);
          // sync input boxes
          qsa('.awhb__controls input', root).forEach(function(inp){
            if(inp.previousSibling && inp.previousSibling.textContent==='Word Count') inp.value=String(state.word_count);
            if(inp.previousSibling && inp.previousSibling.textContent==='Page Count') inp.value=String(state.page_count);
            if(inp.previousSibling && inp.previousSibling.textContent==='Item Count') inp.value=String(state.item_count);
          });
        }
        renderTotals();
        renderOptions();
      });
      toggle.appendChild(cb);
      toggle.appendChild(el('span', {text:'Select'}));
      right.appendChild(toggle);

      top.appendChild(left);
      top.appendChild(right);

      var price = el('div', {class:'awhb__cardPrice', text: money(0, settings.currency_symbol)});
      var optsWrap = el('div', {class:'awhb__opts', 'data-service': String(service.id)});
      card.appendChild(top);
      card.appendChild(price);
      card.appendChild(optsWrap);

      function renderPrice(){
        var line = state.selected[service.id] ? computeLine(service, state.tier, {
          word_count: state.word_count,
          page_count: state.page_count,
          item_count: state.item_count
        }, state.options[service.id] || {}) : 0;
        price.textContent = state.selected[service.id] ? ('Est: ' + money(line, settings.currency_symbol)) : '';
      }

      function renderServiceOptions(){
        optsWrap.innerHTML = '';
        if(!state.selected[service.id]) return;
        var opts = service.options || [];
        if(!opts.length) return;
        var current = state.options[service.id] || {};
        opts.forEach(function(opt){
          var field = el('div', {class:'awhb__optField'});
          field.appendChild(el('label', {text: opt.label + (opt.required ? ' *' : '')}));
          var type = opt.type || 'select';
          var choices = opt.choices || [];
          if(type==='checkbox'){
            var list = el('div', {class:'awhb__checkList'});
            choices.forEach(function(ch){
              var row = el('label', {class:'awhb__check'});
              var c = el('input'); c.type='checkbox'; c.value=ch.id;
              var cur = current[opt.id];
              var arr = Array.isArray(cur) ? cur : [];
              c.checked = arr.indexOf(ch.id)!==-1;
              c.addEventListener('change', function(){
                var cur2 = current[opt.id];
                var arr2 = Array.isArray(cur2) ? cur2.slice() : [];
                if(c.checked && arr2.indexOf(ch.id)===-1) arr2.push(ch.id);
                if(!c.checked) arr2 = arr2.filter(function(x){ return x!==ch.id; });
                current[opt.id]=arr2;
                state.options[service.id]=current;
                renderPrice(); renderTotals();
              });
              row.appendChild(c);
              row.appendChild(el('span', {text: ch.label}));
              list.appendChild(row);
            });
            field.appendChild(list);
          } else {
            var s = el('select');
            var ph = el('option'); ph.value=''; ph.textContent = 'Select';
            s.appendChild(ph);
            choices.forEach(function(ch){
              var o=el('option'); o.value=ch.id; o.textContent = ch.label;
              s.appendChild(o);
            });
            s.value = current[opt.id] || '';
            s.addEventListener('change', function(){
              current[opt.id]=this.value;
              state.options[service.id]=current;
              renderPrice(); renderTotals();
            });
            field.appendChild(s);
          }
          optsWrap.appendChild(field);
        });
      }

      card._renderPrice = renderPrice;
      card._renderOptions = renderServiceOptions;
      return card;
    }

    var cards = services.map(serviceCard);
    cards.forEach(function(c){ grid.appendChild(c); });

    function renderOptions(){
      cards.forEach(function(c){ c._renderOptions && c._renderOptions(); });
      cards.forEach(function(c){ c._renderPrice && c._renderPrice(); });
    }

    function buildPayload(){
      var selectedServices = [];
      var total = 0;
      services.forEach(function(s){
        if(!state.selected[s.id]) return;
        var line = computeLine(s, state.tier, {
          word_count: state.word_count,
          page_count: state.page_count,
          item_count: state.item_count
        }, state.options[s.id] || {});
        total += line;
        selectedServices.push({
          id: s.id,
          title: s.title,
          line_total: line,
          options: state.options[s.id] || {}
        });
      });
      total = Math.round(total*100)/100;

      return {
        tier: state.tier,
        quantities: { word_count: state.word_count, page_count: state.page_count, item_count: state.item_count },
        services: selectedServices,
        total: total
      };
    }

    function renderTotals(){
      var payload = buildPayload();
      totalValue.textContent = money(payload.total, settings.currency_symbol);
      selectedList.innerHTML = '';
      if(!payload.services.length){
        selectedList.appendChild(el('div', {class:'awhb__muted', text:'No services selected yet.'}));
      } else {
        payload.services.forEach(function(s){
          var row = el('div', {class:'awhb__selRow'});
          row.appendChild(el('div', {class:'awhb__selName', text: s.title}));
          row.appendChild(el('div', {class:'awhb__selPrice', text: money(s.line_total, settings.currency_symbol)}));
          selectedList.appendChild(row);
        });
      }
      cards.forEach(function(c){ c._renderPrice && c._renderPrice(); });
    }

    root.innerHTML = '';
    root.appendChild(header);
    root.appendChild(controls);

    var layout = el('div', {class:'awhb__layout'});
    layout.appendChild(grid);
    layout.appendChild(summary);

    root.appendChild(layout);
    root.appendChild(modal);

    renderOptions();
    renderTotals();
  }

  function boot(){
    qsa('[data-awhb-root="1"]').forEach(function(root){
      fetchConfig().then(function(cfg){
        mount(root, cfg);
      }).catch(function(){
        root.innerHTML = '<div class="awhb__error">Unable to load calculator configuration.</div>';
      });
    });
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();