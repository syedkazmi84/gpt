<?php
defined('ABSPATH') || exit;

use AuthorWings\PublishingCalculator\AWPC_Config;

$option_key = AWPC_Config::option_key();
?>
<div class="wrap awpc-admin">
	<h1><?php echo esc_html__('AuthorWings Calculator', 'authorwings-publishing-calculator'); ?></h1>

	<form method="post" action="options.php">
		<?php settings_fields('awpc_settings'); ?>

		<div class="awpc-grid">
			<div class="awpc-card">
				<h2><?php echo esc_html__('Currency and Tax', 'authorwings-publishing-calculator'); ?></h2>

				<div class="awpc-field">
					<label><?php echo esc_html__('Currency Code', 'authorwings-publishing-calculator'); ?></label>
					<input type="text" name="<?php echo esc_attr($option_key); ?>[currency][code]" value="<?php echo esc_attr($config['currency']['code']); ?>" />
				</div>

				<div class="awpc-field">
					<label><?php echo esc_html__('Currency Symbol', 'authorwings-publishing-calculator'); ?></label>
					<input type="text" name="<?php echo esc_attr($option_key); ?>[currency][symbol]" value="<?php echo esc_attr($config['currency']['symbol']); ?>" />
				</div>

				<div class="awpc-field">
					<label><?php echo esc_html__('Symbol Position', 'authorwings-publishing-calculator'); ?></label>
					<select name="<?php echo esc_attr($option_key); ?>[currency][position]">
						<option value="before" <?php selected($config['currency']['position'], 'before'); ?>><?php echo esc_html__('Before amount', 'authorwings-publishing-calculator'); ?></option>
						<option value="after" <?php selected($config['currency']['position'], 'after'); ?>><?php echo esc_html__('After amount', 'authorwings-publishing-calculator'); ?></option>
					</select>
				</div>

				<div class="awpc-field awpc-inline">
					<label>
						<input type="checkbox" name="<?php echo esc_attr($option_key); ?>[currency][tax_enabled]" value="1" <?php checked(!empty($config['currency']['tax_enabled'])); ?> />
						<?php echo esc_html__('Enable Tax', 'authorwings-publishing-calculator'); ?>
					</label>
				</div>

				<div class="awpc-field">
					<label><?php echo esc_html__('Tax Rate (%)', 'authorwings-publishing-calculator'); ?></label>
					<input type="number" step="0.01" min="0" name="<?php echo esc_attr($option_key); ?>[currency][tax_rate]" value="<?php echo esc_attr($config['currency']['tax_rate']); ?>" />
				</div>
			</div>

			<div class="awpc-card">
				<h2><?php echo esc_html__('UI Defaults', 'authorwings-publishing-calculator'); ?></h2>

				<div class="awpc-field">
					<label><?php echo esc_html__('Default Tier', 'authorwings-publishing-calculator'); ?></label>
					<select name="<?php echo esc_attr($option_key); ?>[ui][default_tier]">
						<option value="basic" <?php selected($config['ui']['default_tier'], 'basic'); ?>>Basic</option>
						<option value="standard" <?php selected($config['ui']['default_tier'], 'standard'); ?>>Standard</option>
						<option value="premium" <?php selected($config['ui']['default_tier'], 'premium'); ?>>Premium</option>
					</select>
				</div>

				<div class="awpc-field awpc-inline">
					<label>
						<input type="checkbox" name="<?php echo esc_attr($option_key); ?>[ui][enable_promo_codes]" value="1" <?php checked(!empty($config['ui']['enable_promo_codes'])); ?> />
						<?php echo esc_html__('Enable Promo Codes', 'authorwings-publishing-calculator'); ?>
					</label>
				</div>

				<div class="awpc-field awpc-inline">
					<label>
						<input type="checkbox" name="<?php echo esc_attr($option_key); ?>[ui][show_timeline_estimate]" value="1" <?php checked(!empty($config['ui']['show_timeline_estimate'])); ?> />
						<?php echo esc_html__('Show Timeline Estimate', 'authorwings-publishing-calculator'); ?>
					</label>
				</div>
			</div>

			<div class="awpc-card">
				<h2><?php echo esc_html__('Webhook', 'authorwings-publishing-calculator'); ?></h2>
				<div class="awpc-field awpc-inline">
					<label>
						<input type="checkbox" name="<?php echo esc_attr($option_key); ?>[webhook][enabled]" value="1" <?php checked(!empty($config['webhook']['enabled'])); ?> />
						<?php echo esc_html__('Enable Webhook', 'authorwings-publishing-calculator'); ?>
					</label>
				</div>
				<div class="awpc-field">
					<label><?php echo esc_html__('Webhook URL (Zapier/Make)', 'authorwings-publishing-calculator'); ?></label>
					<input type="url" name="<?php echo esc_attr($option_key); ?>[webhook][url]" value="<?php echo esc_attr($config['webhook']['url']); ?>" />
				</div>
			</div>

			<div class="awpc-card awpc-card-wide">
				<h2><?php echo esc_html__('Email Settings and Templates', 'authorwings-publishing-calculator'); ?></h2>

				<div class="awpc-field">
					<label><?php echo esc_html__('Admin To', 'authorwings-publishing-calculator'); ?></label>
					<input type="email" name="<?php echo esc_attr($option_key); ?>[emails][admin_to]" value="<?php echo esc_attr($config['emails']['admin_to']); ?>" />
				</div>

				<div class="awpc-two">
					<div class="awpc-field">
						<label><?php echo esc_html__('From Name', 'authorwings-publishing-calculator'); ?></label>
						<input type="text" name="<?php echo esc_attr($option_key); ?>[emails][from_name]" value="<?php echo esc_attr($config['emails']['from_name']); ?>" />
					</div>
					<div class="awpc-field">
						<label><?php echo esc_html__('From Email', 'authorwings-publishing-calculator'); ?></label>
						<input type="email" name="<?php echo esc_attr($option_key); ?>[emails][from_email]" value="<?php echo esc_attr($config['emails']['from_email']); ?>" />
					</div>
				</div>

				<div class="awpc-two">
					<div class="awpc-field">
						<label><?php echo esc_html__('Admin Subject', 'authorwings-publishing-calculator'); ?></label>
						<input type="text" name="<?php echo esc_attr($option_key); ?>[emails][admin_subject]" value="<?php echo esc_attr($config['emails']['admin_subject']); ?>" />
					</div>
					<div class="awpc-field">
						<label><?php echo esc_html__('Customer Subject', 'authorwings-publishing-calculator'); ?></label>
						<input type="text" name="<?php echo esc_attr($option_key); ?>[emails][customer_subject]" value="<?php echo esc_attr($config['emails']['customer_subject']); ?>" />
					</div>
				</div>

				<p class="description">
					<?php echo esc_html__('Placeholders: {{name}}, {{email}}, {{phone}}, {{currency}}, {{total}}, {{timeline}}, {{items}}, {{json}}', 'authorwings-publishing-calculator'); ?>
				</p>

				<div class="awpc-two">
					<div class="awpc-field">
						<label><?php echo esc_html__('Admin Template', 'authorwings-publishing-calculator'); ?></label>
						<textarea rows="10" name="<?php echo esc_attr($option_key); ?>[emails][admin_template]"><?php echo esc_textarea($config['emails']['admin_template']); ?></textarea>
					</div>
					<div class="awpc-field">
						<label><?php echo esc_html__('Customer Template', 'authorwings-publishing-calculator'); ?></label>
						<textarea rows="10" name="<?php echo esc_attr($option_key); ?>[emails][customer_template]"><?php echo esc_textarea($config['emails']['customer_template']); ?></textarea>
					</div>
				</div>
			</div>

			<div class="awpc-card awpc-card-wide">
				<h2><?php echo esc_html__('Services JSON', 'authorwings-publishing-calculator'); ?></h2>
				<textarea class="awpc-json" rows="18" name="<?php echo esc_attr($option_key); ?>[services_json]"><?php echo esc_textarea(wp_json_encode($config['services'], JSON_PRETTY_PRINT)); ?></textarea>
			</div>

			<div class="awpc-card">
				<h2><?php echo esc_html__('Promo Codes JSON', 'authorwings-publishing-calculator'); ?></h2>
				<textarea class="awpc-json" rows="12" name="<?php echo esc_attr($option_key); ?>[promo_json]"><?php echo esc_textarea(wp_json_encode($config['promo_codes'], JSON_PRETTY_PRINT)); ?></textarea>
			</div>

			<div class="awpc-card">
				<h2><?php echo esc_html__('Bundle Discounts JSON', 'authorwings-publishing-calculator'); ?></h2>
				<textarea class="awpc-json" rows="12" name="<?php echo esc_attr($option_key); ?>[bundle_json]"><?php echo esc_textarea(wp_json_encode($config['bundle_discounts'], JSON_PRETTY_PRINT)); ?></textarea>
			</div>

			<div class="awpc-card awpc-card-wide">
				<h2><?php echo esc_html__('Lead Fields JSON', 'authorwings-publishing-calculator'); ?></h2>
				<textarea class="awpc-json" rows="12" name="<?php echo esc_attr($option_key); ?>[lead_fields_json]"><?php echo esc_textarea(wp_json_encode($config['lead_fields'], JSON_PRETTY_PRINT)); ?></textarea>
			</div>
		</div>

		<?php submit_button(__('Save Changes', 'authorwings-publishing-calculator')); ?>
	</form>
</div>
