<?php
namespace AuthorWings\PublishingCalculator\Admin;

use AuthorWings\PublishingCalculator\AWPC_Config;

defined('ABSPATH') || exit;

final class AWPC_Admin {

	private $config;

	public function __construct(AWPC_Config $config) { $this->config = $config; }

	public function register_menu() {
		add_menu_page(
			__('AuthorWings Calculator', 'authorwings-publishing-calculator'),
			__('AuthorWings Calculator', 'authorwings-publishing-calculator'),
			'manage_options',
			'awpc_admin',
			array($this, 'render_page'),
			'dashicons-calculator',
			56
		);
	}

	public function register_settings() {
		register_setting('awpc_settings', AWPC_Config::option_key(), array(
			'type' => 'array',
			'sanitize_callback' => array($this, 'sanitize_config'),
			'default' => AWPC_Config::default_config(),
		));
	}

	public function enqueue_assets($hook) {
		if ('toplevel_page_awpc_admin' !== $hook) { return; }

		wp_enqueue_style(
			'awpc-admin',
			plugins_url('admin/assets/admin.css', dirname(__FILE__, 2) . '/authorwings-publishing-calculator.php'),
			array(),
			AWPC_VERSION
		);

		wp_enqueue_script(
			'awpc-admin',
			plugins_url('admin/assets/admin.js', dirname(__FILE__, 2) . '/authorwings-publishing-calculator.php'),
			array(),
			AWPC_VERSION,
			true
		);
	}

	public function render_page() {
		if (!current_user_can('manage_options')) {
			wp_die(esc_html__('You do not have permission to access this page.', 'authorwings-publishing-calculator'));
		}

		$config = $this->config->get();
		include __DIR__ . '/views/page-admin.php';
	}

	public function sanitize_config($input) {
		if (!current_user_can('manage_options')) { return $this->config->get(); }

		$clean = $this->config->get();

		if (isset($input['currency']) && is_array($input['currency'])) {
			$clean['currency']['code'] = sanitize_text_field($input['currency']['code'] ?? $clean['currency']['code']);
			$clean['currency']['symbol'] = sanitize_text_field($input['currency']['symbol'] ?? $clean['currency']['symbol']);
			$pos = sanitize_key($input['currency']['position'] ?? $clean['currency']['position']);
			$clean['currency']['position'] = in_array($pos, array('before','after'), true) ? $pos : 'before';
			$clean['currency']['thousand_sep'] = sanitize_text_field($input['currency']['thousand_sep'] ?? ',');
			$clean['currency']['decimal_sep'] = sanitize_text_field($input['currency']['decimal_sep'] ?? '.');
			$clean['currency']['tax_enabled'] = !empty($input['currency']['tax_enabled']);
			$clean['currency']['tax_rate'] = max(0, (float) ($input['currency']['tax_rate'] ?? 0));
		}

		if (isset($input['ui']) && is_array($input['ui'])) {
			$tier = sanitize_key($input['ui']['default_tier'] ?? $clean['ui']['default_tier']);
			$clean['ui']['default_tier'] = in_array($tier, array('basic','standard','premium'), true) ? $tier : 'standard';
			$clean['ui']['enable_promo_codes'] = !empty($input['ui']['enable_promo_codes']);
			$clean['ui']['show_timeline_estimate'] = !empty($input['ui']['show_timeline_estimate']);
		}

		if (isset($input['webhook']) && is_array($input['webhook'])) {
			$clean['webhook']['enabled'] = !empty($input['webhook']['enabled']);
			$clean['webhook']['url'] = esc_url_raw($input['webhook']['url'] ?? '');
		}

		if (isset($input['emails']) && is_array($input['emails'])) {
			$clean['emails']['admin_to'] = sanitize_email($input['emails']['admin_to'] ?? $clean['emails']['admin_to']);
			$clean['emails']['from_name'] = sanitize_text_field($input['emails']['from_name'] ?? $clean['emails']['from_name']);
			$clean['emails']['from_email'] = sanitize_email($input['emails']['from_email'] ?? $clean['emails']['from_email']);
			$clean['emails']['admin_subject'] = sanitize_text_field($input['emails']['admin_subject'] ?? $clean['emails']['admin_subject']);
			$clean['emails']['customer_subject'] = sanitize_text_field($input['emails']['customer_subject'] ?? $clean['emails']['customer_subject']);
			$clean['emails']['admin_template'] = wp_kses_post($input['emails']['admin_template'] ?? $clean['emails']['admin_template']);
			$clean['emails']['customer_template'] = wp_kses_post($input['emails']['customer_template'] ?? $clean['emails']['customer_template']);
		}

		$clean['services'] = $this->sanitize_json_field($input['services_json'] ?? '', $clean['services']);
		$clean['promo_codes'] = $this->sanitize_json_field($input['promo_json'] ?? '', $clean['promo_codes']);
		$clean['bundle_discounts'] = $this->sanitize_json_field($input['bundle_json'] ?? '', $clean['bundle_discounts']);
		$clean['lead_fields'] = $this->sanitize_json_field($input['lead_fields_json'] ?? '', $clean['lead_fields']);

		return $clean;
	}

	private function sanitize_json_field($raw, $fallback) {
		$raw = (string) $raw;
		$raw = wp_unslash($raw);
		$data = json_decode($raw, true);
		return is_array($data) ? $data : $fallback;
	}
}
