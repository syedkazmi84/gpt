(function(){
  // placeholder for future UI helpers
})();