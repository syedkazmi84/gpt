(function(wp){
  const { registerBlockType } = wp.blocks;
  const { InspectorControls } = wp.blockEditor;
  const { PanelBody, TextControl, ToggleControl, SelectControl } = wp.components;
  const { __ } = wp.i18n;

  registerBlockType('authorwings/awpc-hybrid-builder', {
    edit: (props) => {
      const { attributes, setAttributes } = props;

      return [
        wp.element.createElement(InspectorControls, { key: 'inspector' },
          wp.element.createElement(PanelBody, { title: __('Settings', 'authorwings-publishing-calculator'), initialOpen: true },
            wp.element.createElement(TextControl, {
              label: __('Default currency code (optional)', 'authorwings-publishing-calculator'),
              value: attributes.defaultCurrency,
              onChange: (v) => setAttributes({ defaultCurrency: v })
            }),
            wp.element.createElement(SelectControl, {
              label: __('Default tier (optional)', 'authorwings-publishing-calculator'),
              value: attributes.defaultTier,
              options: [
                { label: __('Use plugin default', 'authorwings-publishing-calculator'), value: '' },
                { label: 'Basic', value: 'basic' },
                { label: 'Standard', value: 'standard' },
                { label: 'Premium', value: 'premium' }
              ],
              onChange: (v) => setAttributes({ defaultTier: v })
            }),
            wp.element.createElement(ToggleControl, {
              label: __('Enable promo codes', 'authorwings-publishing-calculator'),
              checked: !!attributes.enablePromoCodes,
              onChange: (v) => setAttributes({ enablePromoCodes: !!v })
            }),
            wp.element.createElement(ToggleControl, {
              label: __('Show timeline estimate', 'authorwings-publishing-calculator'),
              checked: !!attributes.showTimeline,
              onChange: (v) => setAttributes({ showTimeline: !!v })
            })
          )
        ),
        wp.element.createElement('div', { key: 'preview', style: { border: '1px dashed #cfd2da', padding: '14px', borderRadius: '10px' } },
          wp.element.createElement('strong', null, 'AuthorWings Hybrid Builder'),
          wp.element.createElement('div', { style: { marginTop: '6px', color: '#6b7280' } }, 'This block renders the hybrid calculator on the frontend.')
        )
      ];
    },
    save: () => null
  });
})(window.wp);