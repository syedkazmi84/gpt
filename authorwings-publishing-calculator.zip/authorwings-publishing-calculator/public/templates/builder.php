<?php
defined('ABSPATH') || exit;

$mode = isset($view['mode']) ? sanitize_key($view['mode']) : 'hybrid';
$atts = isset($view['atts']) && is_array($view['atts']) ? $view['atts'] : array();

$default_currency = isset($atts['default_currency']) ? sanitize_text_field($atts['default_currency']) : '';
$default_tier = isset($atts['default_tier']) ? sanitize_key($atts['default_tier']) : '';
$enable_promo = isset($atts['enable_promo_codes']) ? sanitize_text_field($atts['enable_promo_codes']) : '';
$show_timeline = isset($atts['show_timeline_estimate']) ? sanitize_text_field($atts['show_timeline_estimate']) : '';

$instance_id = 'awpc_' . wp_generate_uuid4();
?>
<div class="awpc-root"
  id="<?php echo esc_attr($instance_id); ?>"
  data-mode="<?php echo esc_attr($mode); ?>"
  data-default-currency="<?php echo esc_attr($default_currency); ?>"
  data-default-tier="<?php echo esc_attr($default_tier); ?>"
  data-enable-promo="<?php echo esc_attr($enable_promo); ?>"
  data-show-timeline="<?php echo esc_attr($show_timeline); ?>"
>
  <div class="awpc-shell" role="region" aria-label="<?php echo esc_attr__('Publishing cost calculator', 'authorwings-publishing-calculator'); ?>">
    <div class="awpc-header">
      <div>
        <div class="awpc-kicker"><?php echo esc_html__('AuthorWings', 'authorwings-publishing-calculator'); ?></div>
        <h2 class="awpc-title"><?php echo esc_html__('Build Your Publishing Package', 'authorwings-publishing-calculator'); ?></h2>
        <p class="awpc-subtitle"><?php echo esc_html__('Select services, customize details, and get an instant estimate.', 'authorwings-publishing-calculator'); ?></p>
      </div>
      <div class="awpc-steps" aria-label="<?php echo esc_attr__('Steps', 'authorwings-publishing-calculator'); ?>">
        <button type="button" class="awpc-step is-active" data-step="1">1 <?php echo esc_html__('Services', 'authorwings-publishing-calculator'); ?></button>
        <button type="button" class="awpc-step" data-step="2">2 <?php echo esc_html__('Details', 'authorwings-publishing-calculator'); ?></button>
        <button type="button" class="awpc-step" data-step="3">3 <?php echo esc_html__('Add-ons', 'authorwings-publishing-calculator'); ?></button>
        <button type="button" class="awpc-step" data-step="4">4 <?php echo esc_html__('Summary', 'authorwings-publishing-calculator'); ?></button>
      </div>
    </div>

    <div class="awpc-body">
      <div class="awpc-main">
        <div class="awpc-panel" data-panel="1"></div>
        <div class="awpc-panel" data-panel="2" hidden></div>
        <div class="awpc-panel" data-panel="3" hidden></div>
        <div class="awpc-panel" data-panel="4" hidden></div>

        <div class="awpc-actions">
          <button type="button" class="awpc-btn awpc-btn-ghost" data-action="prev"><?php echo esc_html__('Back', 'authorwings-publishing-calculator'); ?></button>
          <div class="awpc-actions-right">
            <button type="button" class="awpc-btn awpc-btn-secondary" data-action="save"><?php echo esc_html__('Save Package', 'authorwings-publishing-calculator'); ?></button>
            <button type="button" class="awpc-btn awpc-btn-primary" data-action="next"><?php echo esc_html__('Continue', 'authorwings-publishing-calculator'); ?></button>
          </div>
        </div>

        <div class="awpc-toast" role="status" aria-live="polite" hidden></div>
      </div>

      <aside class="awpc-summary" aria-label="<?php echo esc_attr__('Summary', 'authorwings-publishing-calculator'); ?>">
        <button type="button" class="awpc-summary-toggle" aria-expanded="false">
          <span><?php echo esc_html__('Summary', 'authorwings-publishing-calculator'); ?></span>
          <span class="awpc-summary-total" data-bind="total"></span>
        </button>

        <div class="awpc-summary-inner" hidden>
          <div class="awpc-summary-card">
            <div class="awpc-summary-row">
              <div class="awpc-summary-label"><?php echo esc_html__('Estimated total', 'authorwings-publishing-calculator'); ?></div>
              <div class="awpc-summary-value" data-bind="total"></div>
            </div>

            <div class="awpc-summary-row" data-bind-wrap="timeline">
              <div class="awpc-summary-label"><?php echo esc_html__('Timeline estimate', 'authorwings-publishing-calculator'); ?></div>
              <div class="awpc-summary-value" data-bind="timeline"></div>
            </div>

            <div class="awpc-summary-divider"></div>
            <div class="awpc-summary-items" data-bind="items"></div>
            <div class="awpc-summary-divider"></div>

            <div class="awpc-summary-cta">
              <button type="button" class="awpc-btn awpc-btn-primary" data-action="quote"><?php echo esc_html__('Request Quote', 'authorwings-publishing-calculator'); ?></button>
              <button type="button" class="awpc-btn awpc-btn-ghost" data-action="email"><?php echo esc_html__('Email Summary', 'authorwings-publishing-calculator'); ?></button>
            </div>

            <p class="awpc-note"><?php echo esc_html__('Estimates are non-binding and subject to final manuscript review.', 'authorwings-publishing-calculator'); ?></p>
          </div>
        </div>
      </aside>
    </div>

    <div class="awpc-modal" hidden>
      <div class="awpc-modal-backdrop" data-action="close"></div>
      <div class="awpc-modal-card" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr__('Request quote', 'authorwings-publishing-calculator'); ?>">
        <div class="awpc-modal-head">
          <div>
            <div class="awpc-modal-title"><?php echo esc_html__('Request a Quote', 'authorwings-publishing-calculator'); ?></div>
            <div class="awpc-modal-sub"><?php echo esc_html__('Submit your details and we will contact you shortly.', 'authorwings-publishing-calculator'); ?></div>
          </div>
          <button type="button" class="awpc-x" data-action="close" aria-label="<?php echo esc_attr__('Close', 'authorwings-publishing-calculator'); ?>">×</button>
        </div>

        <form class="awpc-form" data-form="quote">
          <input type="text" name="hp" value="" class="awpc-hp" tabindex="-1" autocomplete="off" />
          <div class="awpc-form-fields" data-bind="leadFields"></div>

          <div class="awpc-form-actions">
            <button type="button" class="awpc-btn awpc-btn-ghost" data-action="close"><?php echo esc_html__('Cancel', 'authorwings-publishing-calculator'); ?></button>
            <button type="submit" class="awpc-btn awpc-btn-primary"><?php echo esc_html__('Submit Request', 'authorwings-publishing-calculator'); ?></button>
          </div>

          <div class="awpc-form-status" role="status" aria-live="polite"></div>
        </form>
      </div>
    </div>

  </div>
</div>
