(function(){
  function q(root,sel){return root.querySelector(sel);}
  function qa(root,sel){return Array.from(root.querySelectorAll(sel));}
  function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  function money(cfg, amt){
    const sym = cfg.currency?.symbol || '$';
    const pos = cfg.currency?.position || 'before';
    const n = Number(amt||0).toFixed(2);
    return pos === 'after' ? `${n}${sym}` : `${sym}${n}`;
  }
  async function post(params){
    const res = await fetch(AWPC_PUBLIC.ajax_url, {
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
      body: new URLSearchParams(params)
    });
    return res.json();
  }
  async function fetchConfig(){
    const json = await post({action:'awpc_get_config', nonce: AWPC_PUBLIC.nonce});
    if(!json || !json.success) throw new Error(json?.data?.message || 'Config error');
    return json.data.config;
  }
  function group(services){
    const g={};
    (services||[]).forEach(s=>{
      if(!s||!s.enabled) return;
      const c=s.category||'Services';
      g[c]=g[c]||[];
      g[c].push(s);
    });
    return g;
  }
  function selection(state){
    return { tier: state.tier, promo: state.promo||'', quantities:{
      word_count: state.word_count||0, page_count: state.page_count||0, isbn_count: state.isbn_count||0, rush: !!state.rush
    }, services: state.services };
  }
  function estimate(cfg, sel){
    const tier = sel.tier || cfg.ui?.default_tier || 'standard';
    const qv = sel.quantities||{};
    const wc=Number(qv.word_count||0), pc=Number(qv.page_count||0), ic=Number(qv.isbn_count||0);
    const rush=!!qv.rush;

    const byId={};
    (cfg.services||[]).forEach(s=>{ if(s?.id) byId[s.id]=s; });

    let items=[], subtotal=0, timeline=0;

    Object.keys(sel.services||{}).forEach(id=>{
      const svc=byId[id]; if(!svc||!svc.enabled) return;
      const model=svc.pricing?.model||'flat';
      let line=Number(svc.pricing?.base||0);
      const unit=Number(svc.pricing?.unit_price||0);
      if(model==='per_word') line += unit*wc;
      if(model==='per_page') line += unit*pc;
      if(model==='per_item') line += unit*(id==='isbn'?ic:1);
      line *= Number(svc.tiers?.[tier]||1);

      const chosen = sel.services?.[id]?.options || {};
      (svc.options||[]).forEach(opt=>{
        const key=opt.key; if(!key || !(key in chosen)) return;
        const val=chosen[key];
        (opt.choices||[]).forEach(ch=>{ if(String(ch.value)===String(val)) line += Number(ch.price_delta||0); });
        if(opt.price && opt.price.type==='flat'){
          const on = val===true || String(val)==='1' || String(val)==='true';
          if(on) line += Number(opt.price.value||0);
        }
        if(opt.price && opt.price.type==='multiplier'){
          const n = Number(val||0), baseN = Number(opt.default||1);
          const extra = Math.max(0,n-baseN);
          line += (line * Number(opt.price.value||0) * extra);
        }
      });

      items.push({name: svc.name, amount: Number(line.toFixed(2))});
      subtotal += line;

      const td=svc.timeline_days||{};
      const base=Number(td.base_days||0), per=Number(td.per_unit_days||0), size=Math.max(1,Number(td.unit_size||1));
      let units=1;
      if(model==='per_word' && wc>0) units=Math.ceil(wc/size);
      if(model==='per_page' && pc>0) units=Math.ceil(pc/size);
      timeline = Math.max(timeline, base + per*Math.max(0,units-1));
    });

    let discounts=0;
    const ids=Object.keys(sel.services||{});
    (cfg.bundle_discounts||[]).forEach(r=>{
      const req=r.requires||[];
      if(!req.every(x=>ids.includes(String(x)))) return;
      const val=Number(r.value||0);
      if(r.type==='percent') discounts += subtotal*(val/100);
      if(r.type==='fixed') discounts += val;
    });

    const promo=(sel.promo||'').toUpperCase().replace(/\s+/g,'');
    if(promo){
      const pcfg=(cfg.promo_codes||[]).find(p=>String(p.code||'').toUpperCase().replace(/\s+/g,'')===promo);
      if(pcfg){
        const val=Number(pcfg.value||0);
        if(pcfg.type==='percent') discounts += subtotal*(val/100);
        if(pcfg.type==='fixed') discounts += Math.min(subtotal,val);
      }
    }

    let after=Math.max(0, subtotal - discounts);
    if(rush){ after *= 1.25; timeline = Math.max(1, Math.floor(timeline*0.6)); }

    let tax=0;
    if(cfg.currency?.tax_enabled && Number(cfg.currency?.tax_rate||0)>0){
      tax = after*(Number(cfg.currency.tax_rate)/100);
    }
    const total=after+tax;
    return {items, total:+total.toFixed(2), timeline_days: timeline|0};
  }

  function optionHTML(svc,opt,state){
    const sid=svc.id, key=opt.key, type=opt.type;
    const cur=state.services?.[sid]?.options?.[key];
    const label=esc(opt.label||key);

    if(type==='checkbox'){
      const checked = cur===true ? 'checked':'';
      return `<div class="awpc-field"><label style="display:flex; gap:8px; align-items:center;">
        <input type="checkbox" ${checked} data-svc="${esc(sid)}" data-opt="${esc(key)}" data-type="checkbox"/><span>${label}</span>
      </label></div>`;
    }
    if(type==='select'){
      const choices=opt.choices||[];
      const val=cur!=null?String(cur):String(choices?.[0]?.value??'');
      return `<div class="awpc-field"><label>${label}</label>
        <select data-svc="${esc(sid)}" data-opt="${esc(key)}" data-type="select">
          ${choices.map(ch=>`<option value="${esc(ch.value)}" ${String(ch.value)===val?'selected':''}>${esc(ch.label||ch.value)}</option>`).join('')}
        </select></div>`;
    }
    if(type==='radio'){
      const choices=opt.choices||[];
      const val=cur!=null?String(cur):String(choices?.[0]?.value??'');
      return `<div class="awpc-field"><label>${label}</label>
        <div style="display:flex; flex-direction:column; gap:8px;">
          ${choices.map(ch=>`<label style="display:flex; gap:8px; align-items:center;">
            <input type="radio" name="awpc_${esc(sid)}_${esc(key)}" value="${esc(ch.value)}" ${String(ch.value)===val?'checked':''}
              data-svc="${esc(sid)}" data-opt="${esc(key)}" data-type="radio"/>
            <span>${esc(ch.label||ch.value)}</span>
          </label>`).join('')}
        </div></div>`;
    }
    const min=opt.min!=null?Number(opt.min):0, max=opt.max!=null?Number(opt.max):999999, step=opt.step!=null?Number(opt.step):1;
    const def=opt.default!=null?Number(opt.default):min;
    const val=cur!=null?Number(cur):def;
    return `<div class="awpc-field"><label>${label}</label>
      <input type="number" min="${min}" max="${max}" step="${step}" value="${val}" data-svc="${esc(sid)}" data-opt="${esc(key)}" data-type="number"/>
    </div>`;
  }

  function render(root,cfg,state){
    const p1=q(root,'[data-panel="1"]');
    const g=group(cfg.services||[]);
    let html='';
    Object.keys(g).forEach(cat=>{
      html += `<div class="awpc-block"><h3 style="margin:0 0 10px 0;">${esc(cat)}</h3>`;
      g[cat].forEach(s=>{
        const sel=!!state.services[s.id];
        html += `<div class="awpc-svc ${sel?'is-selected':''}" data-svc="${esc(s.id)}">
          <div style="display:flex; justify-content:space-between; gap:12px;">
            <div>
              <div style="font-weight:900;">${esc(s.name)}</div>
              <div style="color:#6b7280; font-size:13px; margin-top:4px;">${esc(s.description||'')}</div>
            </div>
            <label style="display:flex; gap:8px; align-items:center;">
              <input type="checkbox" data-toggle="${esc(s.id)}" ${sel?'checked':''}/>
              <span>Select</span>
            </label>
          </div>
          <div class="awpc-svc-options" data-options="${esc(s.id)}"></div>
        </div>`;
      });
      html += `</div>`;
    });
    p1.innerHTML = html;

    qa(p1,'input[data-toggle]').forEach(cb=>{
      cb.addEventListener('change', ()=>{
        const id=cb.getAttribute('data-toggle');
        if(cb.checked) state.services[id]=state.services[id]||{options:{}};
        else delete state.services[id];
        render(root,cfg,state);
        update(root,cfg,state);
      });
    });

    (cfg.services||[]).forEach(s=>{
      if(!state.services[s.id]) return;
      const wrap = p1.querySelector(`[data-options="${CSS.escape(s.id)}"]`);
      if(!wrap) return;
      wrap.innerHTML = (s.options||[]).map(opt=>optionHTML(s,opt,state)).join('') || '<div style="color:#6b7280; font-size:13px;">No options for this service.</div>';

      qa(wrap,'[data-opt]').forEach(inp=>{
        inp.addEventListener('change', ()=>{
          const sid=inp.getAttribute('data-svc');
          const key=inp.getAttribute('data-opt');
          const type=inp.getAttribute('data-type');
          state.services[sid]=state.services[sid]||{options:{}};
          state.services[sid].options=state.services[sid].options||{};
          if(type==='checkbox') state.services[sid].options[key]=!!inp.checked;
          else if(type==='radio') {
            const checked = wrap.querySelector(`input[name="${CSS.escape(inp.name)}"]:checked`);
            state.services[sid].options[key] = checked ? checked.value : inp.value;
          } else state.services[sid].options[key]=inp.value;
          update(root,cfg,state);
        });
      });
    });

    const p2=q(root,'[data-panel="2"]');
    p2.innerHTML = `<div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
      <div class="awpc-field"><label>Tier</label>
        <select data-bind="tier">
          <option value="basic" ${state.tier==='basic'?'selected':''}>Basic</option>
          <option value="standard" ${state.tier==='standard'?'selected':''}>Standard</option>
          <option value="premium" ${state.tier==='premium'?'selected':''}>Premium</option>
        </select>
      </div>
      <div class="awpc-field"><label>Rush delivery</label>
        <select data-bind="rush">
          <option value="0" ${!state.rush?'selected':''}>No</option>
          <option value="1" ${state.rush?'selected':''}>Yes</option>
        </select>
      </div>
      <div class="awpc-field"><label>Word count</label><input type="number" min="0" step="1" data-bind="word_count" value="${Number(state.word_count||0)}"/></div>
      <div class="awpc-field"><label>Page count</label><input type="number" min="0" step="1" data-bind="page_count" value="${Number(state.page_count||0)}"/></div>
      <div class="awpc-field"><label>ISBN count</label><input type="number" min="0" step="1" data-bind="isbn_count" value="${Number(state.isbn_count||0)}"/></div>
      <div class="awpc-field"><label>Promo code</label><input type="text" data-bind="promo" value="${esc(state.promo||'')}" ${cfg.ui?.enable_promo_codes?'':'disabled'}/></div>
    </div>`;

    q(p2,'[data-bind="tier"]')?.addEventListener('change',e=>{state.tier=e.target.value;update(root,cfg,state);});
    q(p2,'[data-bind="rush"]')?.addEventListener('change',e=>{state.rush=e.target.value==='1';update(root,cfg,state);});
    q(p2,'[data-bind="word_count"]')?.addEventListener('input',e=>{state.word_count=Number(e.target.value||0);update(root,cfg,state);});
    q(p2,'[data-bind="page_count"]')?.addEventListener('input',e=>{state.page_count=Number(e.target.value||0);update(root,cfg,state);});
    q(p2,'[data-bind="isbn_count"]')?.addEventListener('input',e=>{state.isbn_count=Number(e.target.value||0);update(root,cfg,state);});
    q(p2,'[data-bind="promo"]')?.addEventListener('input',e=>{state.promo=e.target.value;update(root,cfg,state);});
  }

  function update(root,cfg,state){
    const est=estimate(cfg, selection(state));
    qa(root,'[data-bind="total"]').forEach(el=>el.textContent=money(cfg, est.total));
    qa(root,'[data-bind="timeline"]').forEach(el=>el.textContent=`${est.timeline_days||0} days`);
    const itemsWrap=q(root,'[data-bind="items"]');
    if(itemsWrap){
      itemsWrap.innerHTML = est.items.length
        ? est.items.map(i=>`<div class="awpc-item"><span>${esc(i.name)}</span><span>${money(cfg,i.amount)}</span></div>`).join('')
        : '<div style="color:#6b7280; font-size:13px;">No services selected yet.</div>';
    }
  }

  function bindNav(root){
    let step=1;
    function set(n){
      step=n;
      qa(root,'.awpc-step').forEach(b=>b.classList.toggle('is-active', String(b.dataset.step)===String(step)));
      qa(root,'.awpc-panel').forEach(p=>p.hidden = String(p.dataset.panel)!==String(step));
      const next=q(root,'[data-action="next"]');
      if(next) next.textContent = step===4 ? 'Finish' : 'Continue';
    }
    qa(root,'.awpc-step').forEach(b=>b.addEventListener('click',()=>set(Number(b.dataset.step||1))));
    q(root,'[data-action="prev"]')?.addEventListener('click',()=>set(Math.max(1,step-1)));
    q(root,'[data-action="next"]')?.addEventListener('click',()=>set(Math.min(4,step+1)));
    set(1);
  }

  function bindSummaryToggle(root){
    const toggle=q(root,'.awpc-summary-toggle');
    const inner=q(root,'.awpc-summary-inner');
    if(!toggle||!inner) return;
    toggle.addEventListener('click',()=>{
      const open = toggle.getAttribute('aria-expanded')==='true';
      toggle.setAttribute('aria-expanded', open?'false':'true');
      inner.hidden = open;
    });
  }

  function bindActions(root,cfg,state){
    const toast=q(root,'.awpc-toast');
    q(root,'[data-action="save"]')?.addEventListener('click',()=>{
      localStorage.setItem('awpc_saved_package', JSON.stringify({selection: selection(state)}));
      if(toast){ toast.textContent='Package saved on this device.'; toast.hidden=false; setTimeout(()=>toast.hidden=true,2500); }
    });
    q(root,'[data-action="email"]')?.addEventListener('click',()=>{
      const est=estimate(cfg, selection(state));
      const body = encodeURIComponent(`Estimated total: ${money(cfg, est.total)}\nTimeline: ${est.timeline_days} days\n\n` + est.items.map(i=>`- ${i.name}: ${money(cfg,i.amount)}`).join('\n'));
      location.href = `mailto:?subject=${encodeURIComponent('AuthorWings package summary')}&body=${body}`;
    });

    const modal=q(root,'.awpc-modal');
    const close=()=>{ if(modal) modal.hidden=true; };
    const open=()=>{ if(modal) modal.hidden=false; };

    qa(root,'[data-action="close"]').forEach(b=>b.addEventListener('click',close));

    q(root,'[data-action="quote"]')?.addEventListener('click',()=>{
      const lf=q(root,'[data-bind="leadFields"]');
      if(lf){
        lf.innerHTML = (cfg.lead_fields||[]).map(f=>{
          const key=esc(f.key||''); const label=esc(f.label||key);
          const type = f.type==='email'?'email':(f.type==='number'?'number':'text');
          const req = f.required ? 'required' : '';
          return `<div class="awpc-field"><label>${label}${f.required?' *':''}</label><input name="${key}" type="${type}" ${req}/></div>`;
        }).join('');
      }
      const status=q(root,'.awpc-form-status'); if(status) status.textContent='';
      open();
    });

    const form=q(root,'[data-form="quote"]');
    form?.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const status=q(root,'.awpc-form-status'); if(status) status.textContent='Submitting...';
      const fd=new FormData(form);
      const fields={};
      for(const [k,v] of fd.entries()){ if(k==='hp') continue; fields[k]=String(v||''); }
      const payload={ hp:String(fd.get('hp')||''), fields, selection: selection(state), page_url: location.href };
      try{
        const json = await post({action:'awpc_submit_quote', nonce: AWPC_PUBLIC.nonce, payload: JSON.stringify(payload)});
        if(!json || !json.success) throw new Error(json?.data?.message || 'Submission failed');
        if(status) status.textContent = json.data.message || 'Submitted.';
        setTimeout(close, 800);
      }catch(err){
        if(status) status.textContent = err.message || 'Submission failed.';
      }
    });
  }

  function applyOverrides(root,cfg){
    const cur=root.getAttribute('data-default-currency');
    const tier=root.getAttribute('data-default-tier');
    const ep=root.getAttribute('data-enable-promo');
    const st=root.getAttribute('data-show-timeline');
    if(cur) cfg.currency.code=cur;
    if(tier) cfg.ui.default_tier=tier;
    if(ep!=='') cfg.ui.enable_promo_codes = (ep==='1'||ep==='true');
    if(st!=='') cfg.ui.show_timeline_estimate = (st==='1'||st==='true');
  }

  async function boot(root){
    const cfg=await fetchConfig();
    applyOverrides(root,cfg);
    const saved = JSON.parse(localStorage.getItem('awpc_saved_package')||'null');

    const state = { tier: cfg.ui?.default_tier||'standard', promo:'', word_count:0, page_count:0, isbn_count:0, rush:false, services:{} };
    if(saved?.selection){
      const sel=saved.selection;
      state.tier=sel.tier||state.tier;
      state.promo=sel.promo||'';
      state.word_count=Number(sel.quantities?.word_count||0);
      state.page_count=Number(sel.quantities?.page_count||0);
      state.isbn_count=Number(sel.quantities?.isbn_count||0);
      state.rush=!!sel.quantities?.rush;
      state.services=sel.services||{};
    }

    bindSummaryToggle(root);
    bindNav(root);
    render(root,cfg,state);
    bindActions(root,cfg,state);
    update(root,cfg,state);
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    document.querySelectorAll('.awpc-root').forEach(root=>{
      boot(root).catch(()=>{
        const p=q(root,'[data-panel="1"]');
        if(p) p.innerHTML='<div class="awpc-svc"><div style="font-weight:900;">Unable to load calculator.</div><div style="color:#6b7280; font-size:13px; margin-top:4px;">Please refresh or contact support.</div></div>';
      });
    });
  });
})();