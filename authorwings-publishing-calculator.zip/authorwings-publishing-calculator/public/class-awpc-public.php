<?php
namespace AuthorWings\PublishingCalculator\PublicSite;

use AuthorWings\PublishingCalculator\AWPC_Config;

defined('ABSPATH') || exit;

final class AWPC_Public {

	private $config;

	public function __construct(AWPC_Config $config) {
		$this->config = $config;
	}

	public static function flag_assets_needed() {
		// Kept for backward compatibility, but no longer relied on.
	}

	public function maybe_enqueue_assets() {
		if (!$this->page_has_builder()) {
			return;
		}

		wp_enqueue_style(
			'awpc-public',
			plugins_url('public/assets/public.css', dirname(__FILE__, 2) . '/authorwings-publishing-calculator.php'),
			array(),
			AWPC_VERSION
		);

		wp_enqueue_script(
			'awpc-public',
			plugins_url('public/assets/public.js', dirname(__FILE__, 2) . '/authorwings-publishing-calculator.php'),
			array(),
			AWPC_VERSION,
			true
		);

		wp_localize_script('awpc-public', 'AWPC_PUBLIC', array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'nonce'    => wp_create_nonce('awpc_public'),
		));
	}

	private function page_has_builder() {
		if (!is_singular()) {
			return false;
		}

		$post = get_post();
		if (!$post || empty($post->post_content)) {
			return false;
		}

		$content = $post->post_content;

		// Shortcodes
		if (
			has_shortcode($content, 'authorwings_hybrid_builder') ||
			has_shortcode($content, 'authorwings_calculator') ||
			has_shortcode($content, 'authorwings_package_builder')
		) {
			return true;
		}

		// Gutenberg block
		if (function_exists('has_block') && has_block('authorwings/awpc-hybrid-builder', $content)) {
			return true;
		}

		return false;
	}
}
