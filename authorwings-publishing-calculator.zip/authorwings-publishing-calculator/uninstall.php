<?php
defined('WP_UNINSTALL_PLUGIN') || exit;

$option_key = 'awpc_config_v1';
$submissions_table = $GLOBALS['wpdb']->prefix . 'awpc_submissions';

delete_option($option_key);
delete_option('awpc_db_version');

$GLOBALS['wpdb']->query("DROP TABLE IF EXISTS {$submissions_table}");
