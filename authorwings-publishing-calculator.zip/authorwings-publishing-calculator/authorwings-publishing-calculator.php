<?php
/**
 * Plugin Name: AuthorWings Publishing Calculator
 * Plugin URI:  https://authorwings.com
 * Description: Hybrid book publishing services cost calculator + build-your-own package builder with quote requests, promo codes, and admin configuration.
 * Version:     1.0.0
 * Author:      AuthorWings (authorwings.com)
 * Author URI:  https://authorwings.com
 * License:     GPLv2 or later
 * Text Domain: authorwings-publishing-calculator
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

const AWPC_VERSION = '1.0.0';
const AWPC_SLUG    = 'authorwings-publishing-calculator';
const AWPC_PREFIX  = 'awpc_';

require_once __DIR__ . '/includes/class-awpc-autoloader.php';
AuthorWings\PublishingCalculator\AWPC_Autoloader::register(__DIR__ . '/includes');

register_activation_hook(__FILE__, array('AuthorWings\\PublishingCalculator\\AWPC_Activator', 'activate'));
register_deactivation_hook(__FILE__, array('AuthorWings\\PublishingCalculator\\AWPC_Deactivator', 'deactivate'));

function awpc_run_plugin() {
	$plugin = new AuthorWings\PublishingCalculator\AWPC_Plugin(__FILE__);
	$plugin->run();
}
awpc_run_plugin();
