<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Plugin {

	private $plugin_file;

	public function __construct($plugin_file) {
		$this->plugin_file = $plugin_file;
	}

	public function run() {
		require_once __DIR__ . '/helpers.php';

		// These classes live outside /includes, so load them explicitly.
		require_once dirname(__DIR__) . '/admin/class-awpc-admin.php';
		require_once dirname(__DIR__) . '/public/class-awpc-public.php';

		$i18n = new AWPC_I18n();
		add_action('plugins_loaded', array($i18n, 'load_textdomain'));

		$config = new AWPC_Config();
		$calc   = new AWPC_Calculator($config);

		if (is_admin()) {
			$admin = new \AuthorWings\PublishingCalculator\Admin\AWPC_Admin($config);
			add_action('admin_menu', array($admin, 'register_menu'));
			add_action('admin_init', array($admin, 'register_settings'));
			add_action('admin_enqueue_scripts', array($admin, 'enqueue_assets'));
		}

		$public = new \AuthorWings\PublishingCalculator\PublicSite\AWPC_Public($config);
		add_action('wp_enqueue_scripts', array($public, 'maybe_enqueue_assets'));

		$ajax = new AWPC_Ajax($config, $calc);
		$ajax->register();

		$this->register_shortcodes();
		$this->register_block();
	}

	private function register_shortcodes() {
		add_shortcode('authorwings_calculator', array($this, 'shortcode_calculator'));
		add_shortcode('authorwings_package_builder', array($this, 'shortcode_package_builder'));
		add_shortcode('authorwings_hybrid_builder', array($this, 'shortcode_hybrid_builder'));
	}

	public function shortcode_calculator($atts = array()) { return $this->render_builder('calculator', $atts); }
	public function shortcode_package_builder($atts = array()) { return $this->render_builder('package', $atts); }
	public function shortcode_hybrid_builder($atts = array()) { return $this->render_builder('hybrid', $atts); }

	private function render_builder($mode, $atts) {
		$atts = shortcode_atts(
			array(
				'default_currency'       => '',
				'default_tier'           => '',
				'enable_promo_codes'     => '',
				'show_timeline_estimate' => '',
			),
			(array) $atts,
			'authorwings_hybrid_builder'
		);

		\AuthorWings\PublishingCalculator\PublicSite\AWPC_Public::flag_assets_needed();

		ob_start();
		$template = plugin_dir_path($this->plugin_file) . 'public/templates/builder.php';
		$view = array(
			'mode' => sanitize_key($mode),
			'atts' => array_map('sanitize_text_field', $atts),
		);
		include $template;
		return (string) ob_get_clean();
	}

	private function register_block() {
		add_action('init', function () {
			$block_dir = plugin_dir_path($this->plugin_file) . 'blocks';
			if (!file_exists($block_dir . '/block.json')) {
				return;
			}

			wp_register_script(
				'awpc-block',
				plugins_url('blocks/block.js', $this->plugin_file),
				array('wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n'),
				AWPC_VERSION,
				true
			);

			register_block_type($block_dir, array(
				'editor_script' => 'awpc-block',
				'render_callback' => function ($attributes) {
					$atts = array(
						'default_currency'       => isset($attributes['defaultCurrency']) ? $attributes['defaultCurrency'] : '',
						'default_tier'           => isset($attributes['defaultTier']) ? $attributes['defaultTier'] : '',
						'enable_promo_codes'     => !empty($attributes['enablePromoCodes']) ? '1' : '0',
						'show_timeline_estimate' => !empty($attributes['showTimeline']) ? '1' : '0',
					);

					return do_shortcode('[authorwings_hybrid_builder '
						. 'default_currency="' . esc_attr($atts['default_currency']) . '" '
						. 'default_tier="' . esc_attr($atts['default_tier']) . '" '
						. 'enable_promo_codes="' . esc_attr($atts['enable_promo_codes']) . '" '
						. 'show_timeline_estimate="' . esc_attr($atts['show_timeline_estimate']) . '"'
						. ']');
				},
			));
		});
	}
}
