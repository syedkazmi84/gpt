<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

function awpc_get_ip() {
	$ip = '';
	if (!empty($_SERVER['REMOTE_ADDR'])) {
		$ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));
	}
	return $ip;
}

function awpc_safe_json_decode($json) {
	$data = json_decode((string) $json, true);
	return is_array($data) ? $data : array();
}
