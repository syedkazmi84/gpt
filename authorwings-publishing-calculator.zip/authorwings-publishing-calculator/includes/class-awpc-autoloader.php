<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Autoloader {

	public static function register($base_dir) {
		spl_autoload_register(function ($class) use ($base_dir) {
			$prefix = __NAMESPACE__ . '\\';
			if (0 !== strpos($class, $prefix)) {
				return;
			}

			$relative = substr($class, strlen($prefix));
			$relative = strtolower(str_replace('_', '-', $relative));
			$relative = str_replace('\\', '/', $relative);

			$file = trailingslashit($base_dir) . 'class-' . $relative . '.php';
			if (file_exists($file)) {
				require_once $file;
			}
		});
	}
}
