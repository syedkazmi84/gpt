<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Ajax {

	private $config;
	private $calculator;

	public function __construct(AWPC_Config $config, AWPC_Calculator $calculator) {
		$this->config = $config;
		$this->calculator = $calculator;
	}

	public function register() {
		add_action('wp_ajax_awpc_get_config', array($this, 'get_config'));
		add_action('wp_ajax_nopriv_awpc_get_config', array($this, 'get_config'));

		add_action('wp_ajax_awpc_submit_quote', array($this, 'submit_quote'));
		add_action('wp_ajax_nopriv_awpc_submit_quote', array($this, 'submit_quote'));
	}

	public function get_config() {
		check_ajax_referer('awpc_public', 'nonce');

		$cfg = $this->config->get();

		if (isset($cfg['security']['recaptcha']['secret_key'])) {
			$cfg['security']['recaptcha']['secret_key'] = '';
		}

		wp_send_json_success(array('config' => $cfg));
	}

	public function submit_quote() {
		check_ajax_referer('awpc_public', 'nonce');

		$cfg = $this->config->get();

		$ip = awpc_get_ip();
		$max = isset($cfg['security']['rate_limit']['max_per_hour']) ? (int) $cfg['security']['rate_limit']['max_per_hour'] : 6;
		$key = 'awpc_rl_' . md5($ip);
		$used = (int) get_transient($key);

		if ($used >= $max) {
			wp_send_json_error(array('message' => __('Too many requests. Please try again later.', 'authorwings-publishing-calculator')), 429);
		}
		set_transient($key, $used + 1, HOUR_IN_SECONDS);

		$raw = isset($_POST['payload']) ? wp_unslash($_POST['payload']) : '';
		$payload = awpc_safe_json_decode($raw);

		$honeypot = isset($payload['hp']) ? (string) $payload['hp'] : '';
		if ('' !== $honeypot) {
			wp_send_json_error(array('message' => __('Spam detected.', 'authorwings-publishing-calculator')), 400);
		}

		$fields = isset($payload['fields']) && is_array($payload['fields']) ? $payload['fields'] : array();

		$name  = isset($fields['name']) ? sanitize_text_field($fields['name']) : '';
		$email = isset($fields['email']) ? sanitize_email($fields['email']) : '';
		$phone = isset($fields['phone']) ? sanitize_text_field($fields['phone']) : '';

		if ('' === $name || '' === $email || !is_email($email)) {
			wp_send_json_error(array('message' => __('Please provide a valid name and email.', 'authorwings-publishing-calculator')), 400);
		}

		$selection = isset($payload['selection']) && is_array($payload['selection']) ? $payload['selection'] : array();
		$result = $this->calculator->compute($selection);

		$stored = $this->store_submission($name, $email, $phone, $payload, $result);
		if (!$stored) {
			wp_send_json_error(array('message' => __('Could not save your request. Please try again.', 'authorwings-publishing-calculator')), 500);
		}

		$this->maybe_increment_promo_usage($selection);
		$this->send_emails($cfg, $name, $email, $phone, $payload, $result);
		$this->post_webhook($cfg, $name, $email, $phone, $payload, $result);

		wp_send_json_success(array(
			'message' => __('Thanks. Your request has been received.', 'authorwings-publishing-calculator'),
			'result'  => $result,
		));
	}

	private function store_submission($name, $email, $phone, array $payload, array $result) {
		global $wpdb;
		$table = $wpdb->prefix . 'awpc_submissions';

		$data = array(
			'created_at' => current_time('mysql'),
			'status' => 'new',
			'customer_name' => $name,
			'customer_email' => $email,
			'customer_phone' => $phone,
			'payload' => wp_json_encode(array('payload' => $payload, 'computed' => $result)),
			'total_amount' => (float) $result['total'],
			'currency' => sanitize_text_field($result['currency']),
		);

		$formats = array('%s','%s','%s','%s','%s','%s','%f','%s');
		$inserted = $wpdb->insert($table, $data, $formats);
		return (bool) $inserted;
	}

	private function send_emails(array $cfg, $name, $email, $phone, array $payload, array $result) {
		$from_name  = isset($cfg['emails']['from_name']) ? sanitize_text_field($cfg['emails']['from_name']) : 'AuthorWings';
		$from_email = isset($cfg['emails']['from_email']) ? sanitize_email($cfg['emails']['from_email']) : get_option('admin_email');
		$admin_to   = isset($cfg['emails']['admin_to']) ? sanitize_email($cfg['emails']['admin_to']) : get_option('admin_email');

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . $from_name . ' <' . $from_email . '>',
		);

		$items_text = $this->items_text($result);
		$json = wp_json_encode($payload);
		$timeline = !empty($result['timeline_days']) ? $result['timeline_days'] . ' days' : 'N/A';

		$repl = array(
			'{{name}}' => $name,
			'{{email}}' => $email,
			'{{phone}}' => $phone,
			'{{currency}}' => $result['symbol'],
			'{{total}}' => number_format((float) $result['total'], 2),
			'{{timeline}}' => $timeline,
			'{{items}}' => $items_text,
			'{{json}}' => $json,
		);

		$admin_subject = isset($cfg['emails']['admin_subject']) ? (string) $cfg['emails']['admin_subject'] : 'New quote request from {{name}}';
		$cust_subject  = isset($cfg['emails']['customer_subject']) ? (string) $cfg['emails']['customer_subject'] : 'Your AuthorWings quote summary';

		$admin_body = isset($cfg['emails']['admin_template']) ? (string) $cfg['emails']['admin_template'] : '';
		$cust_body  = isset($cfg['emails']['customer_template']) ? (string) $cfg['emails']['customer_template'] : '';

		wp_mail($admin_to, strtr($admin_subject, $repl), strtr($admin_body, $repl), $headers);
		wp_mail($email, strtr($cust_subject, $repl), strtr($cust_body, $repl), $headers);
	}

	private function items_text(array $result) {
		$out = array();
		if (!empty($result['items']) && is_array($result['items'])) {
			foreach ($result['items'] as $item) {
				$name = isset($item['name']) ? (string) $item['name'] : '';
				$amt  = isset($item['amount']) ? (float) $item['amount'] : 0.0;
				$out[] = '- ' . $name . ': ' . $result['symbol'] . number_format($amt, 2);
			}
		}
		return implode("\n", $out);
	}

	private function post_webhook(array $cfg, $name, $email, $phone, array $payload, array $result) {
		if (empty($cfg['webhook']['enabled']) || empty($cfg['webhook']['url'])) { return; }
		$url = esc_url_raw($cfg['webhook']['url']);
		if ('' === $url) { return; }

		$body = array(
			'name' => $name,
			'email' => $email,
			'phone' => $phone,
			'payload' => $payload,
			'computed' => $result,
			'source' => 'authorwings-publishing-calculator',
		);

		wp_remote_post($url, array(
			'timeout' => 10,
			'headers' => array('Content-Type' => 'application/json'),
			'body' => wp_json_encode($body),
		));
	}

	private function maybe_increment_promo_usage(array $selection) {
		$code = isset($selection['promo']) ? sanitize_text_field($selection['promo']) : '';
		if ('' === $code) { return; }

		$code_norm = strtoupper(preg_replace('/\s+/', '', $code));
		$config_key = AWPC_Config::option_key();
		$current = get_option($config_key, array());
		if (!is_array($current) || empty($current['promo_codes']) || !is_array($current['promo_codes'])) { return; }

		foreach ($current['promo_codes'] as $idx => $pc) {
			$pc_code = isset($pc['code']) ? strtoupper(preg_replace('/\s+/', '', (string) $pc['code'])) : '';
			if ($pc_code !== $code_norm) { continue; }

			if (!empty($pc['expires'])) {
				$ts = strtotime((string) $pc['expires']);
				if ($ts && time() > $ts) { return; }
			}

			$limit = isset($pc['usage_limit']) ? (int) $pc['usage_limit'] : 0;
			$used  = isset($pc['used']) ? (int) $pc['used'] : 0;
			if ($limit > 0 && $used >= $limit) { return; }

			$current['promo_codes'][$idx]['used'] = $used + 1;
			update_option($config_key, $current, false);
			return;
		}
	}
}
