<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Deactivator {
	public static function deactivate() {
		// keep data
	}
}
