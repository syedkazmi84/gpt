<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Calculator {

	private $config;

	public function __construct(AWPC_Config $config) { $this->config = $config; }

	public function compute(array $selection) {
		$cfg = $this->config->get();

		$tier = isset($selection['tier']) ? sanitize_key($selection['tier']) : sanitize_key($cfg['ui']['default_tier']);
		if (!in_array($tier, array('basic','standard','premium'), true)) { $tier = 'standard'; }

		$qty = isset($selection['quantities']) && is_array($selection['quantities']) ? $selection['quantities'] : array();
		$word_count = isset($qty['word_count']) ? max(0, (int) $qty['word_count']) : 0;
		$page_count = isset($qty['page_count']) ? max(0, (int) $qty['page_count']) : 0;
		$isbn_count = isset($qty['isbn_count']) ? max(0, (int) $qty['isbn_count']) : 0;
		$rush       = !empty($qty['rush']);

		$selected = isset($selection['services']) && is_array($selection['services']) ? $selection['services'] : array();

		$services_by_id = array();
		foreach ($cfg['services'] as $svc) { if (!empty($svc['id'])) { $services_by_id[$svc['id']] = $svc; } }

		$items = array();
		$subtotal = 0.0;
		$timeline_days = 0;

		foreach ($selected as $svc_id => $svc_payload) {
			$svc_id = sanitize_key($svc_id);
			if (empty($services_by_id[$svc_id])) { continue; }
			$svc = $services_by_id[$svc_id];
			if (empty($svc['enabled'])) { continue; }

			$model = isset($svc['pricing']['model']) ? sanitize_key($svc['pricing']['model']) : 'flat';
			$base  = isset($svc['pricing']['base']) ? (float) $svc['pricing']['base'] : 0.0;
			$unit  = isset($svc['pricing']['unit_price']) ? (float) $svc['pricing']['unit_price'] : 0.0;

			$line = $base;

			if ('per_word' === $model) { $line += $unit * (float) $word_count; }
			elseif ('per_page' === $model) { $line += $unit * (float) $page_count; }
			elseif ('per_item' === $model) {
				$count = ('isbn' === $svc_id) ? $isbn_count : 1;
				$line += $unit * (float) $count;
			}

			$mult = !empty($svc['tiers'][$tier]) ? (float) $svc['tiers'][$tier] : 1.0;
			$line *= $mult;

			$chosen_opts = isset($svc_payload['options']) && is_array($svc_payload['options']) ? $svc_payload['options'] : array();
			$options_def = isset($svc['options']) && is_array($svc['options']) ? $svc['options'] : array();

			foreach ($options_def as $opt) {
				$key = isset($opt['key']) ? sanitize_key($opt['key']) : '';
				if ('' === $key || !array_key_exists($key, $chosen_opts)) { continue; }
				$val = $chosen_opts[$key];

				if (!empty($opt['choices']) && is_array($opt['choices'])) {
					foreach ($opt['choices'] as $choice) {
						$cval = isset($choice['value']) ? (string) $choice['value'] : '';
						if ((string) $val === $cval) {
							$delta = isset($choice['price_delta']) ? (float) $choice['price_delta'] : 0.0;
							$line += $delta;
						}
					}
				}

				if (!empty($opt['price']) && is_array($opt['price'])) {
					$ptype = isset($opt['price']['type']) ? sanitize_key($opt['price']['type']) : '';
					$pval  = isset($opt['price']['value']) ? (float) $opt['price']['value'] : 0.0;

					if ('flat' === $ptype) {
						$on = (true === $val || '1' === (string) $val || 'true' === (string) $val);
						if ($on) { $line += $pval; }
					} elseif ('multiplier' === $ptype) {
						$n = (int) $val;
						$base_n = isset($opt['default']) ? (int) $opt['default'] : 1;
						$extra = max(0, $n - $base_n);
						$line += ($line * $pval * (float) $extra);
					}
				}
			}

			$items[] = array('id' => $svc_id, 'name' => (string) $svc['name'], 'amount' => round($line, 2));
			$subtotal += $line;

			$td = isset($svc['timeline_days']) ? $svc['timeline_days'] : array();
			$base_days = isset($td['base_days']) ? (int) $td['base_days'] : 0;
			$per_unit_days = isset($td['per_unit_days']) ? (int) $td['per_unit_days'] : 0;
			$unit_size = isset($td['unit_size']) ? max(1, (int) $td['unit_size']) : 1;

			$units = 1;
			if ('per_word' === $model && $word_count > 0) { $units = (int) ceil($word_count / $unit_size); }
			elseif ('per_page' === $model && $page_count > 0) { $units = (int) ceil($page_count / $unit_size); }

			$svc_days = $base_days + ($per_unit_days * max(0, $units - 1));
			$timeline_days = max($timeline_days, $svc_days);
		}

		$discount_total = 0.0;
		$selected_ids = array_map('sanitize_key', array_keys($selected));

		if (!empty($cfg['bundle_discounts']) && is_array($cfg['bundle_discounts'])) {
			foreach ($cfg['bundle_discounts'] as $rule) {
				$requires = isset($rule['requires']) && is_array($rule['requires']) ? $rule['requires'] : array();
				$ok = true;
				foreach ($requires as $req) {
					if (!in_array(sanitize_key($req), $selected_ids, true)) { $ok = false; break; }
				}
				if (!$ok) { continue; }
				$type = isset($rule['type']) ? sanitize_key($rule['type']) : '';
				$val  = isset($rule['value']) ? (float) $rule['value'] : 0.0;

				if ('percent' === $type && $val > 0) { $discount_total += ($subtotal * ($val / 100.0)); }
				elseif ('fixed' === $type && $val > 0) { $discount_total += $val; }
			}
		}

		$promo = isset($selection['promo']) ? sanitize_text_field($selection['promo']) : '';
		$promo_discount = 0.0;
		if ('' !== $promo) { $promo_discount = $this->promo_discount_amount($promo, $subtotal, $cfg); $discount_total += $promo_discount; }

		$subtotal_after_discounts = max(0.0, $subtotal - $discount_total);

		if ($rush) { $subtotal_after_discounts *= 1.25; $timeline_days = (int) max(1, floor($timeline_days * 0.6)); }

		$tax = 0.0;
		if (!empty($cfg['currency']['tax_enabled']) && !empty($cfg['currency']['tax_rate'])) {
			$tax_rate = (float) $cfg['currency']['tax_rate'];
			$tax = $subtotal_after_discounts * ($tax_rate / 100.0);
		}

		$total = $subtotal_after_discounts + $tax;

		return array(
			'currency' => $cfg['currency']['code'],
			'symbol' => $cfg['currency']['symbol'],
			'tier' => $tier,
			'items' => $items,
			'subtotal' => round($subtotal, 2),
			'discounts' => round($discount_total, 2),
			'tax' => round($tax, 2),
			'total' => round($total, 2),
			'timeline_days' => (int) $timeline_days,
		);
	}

	private function promo_discount_amount($code, $subtotal, array $cfg) {
		$code_norm = strtoupper(preg_replace('/\s+/', '', (string) $code));
		if (empty($cfg['promo_codes']) || !is_array($cfg['promo_codes'])) { return 0.0; }

		foreach ($cfg['promo_codes'] as $pc) {
			$pc_code = isset($pc['code']) ? strtoupper(preg_replace('/\s+/', '', (string) $pc['code'])) : '';
			if ('' === $pc_code || $pc_code !== $code_norm) { continue; }

			if (!empty($pc['expires'])) {
				$ts = strtotime((string) $pc['expires']);
				if ($ts and time() > $ts) { return 0.0; }
			}

			$limit = isset($pc['usage_limit']) ? (int) $pc['usage_limit'] : 0;
			$used  = isset($pc['used']) ? (int) $pc['used'] : 0;
			if ($limit > 0 && $used >= $limit) { return 0.0; }

			$type = isset($pc['type']) ? sanitize_key($pc['type']) : '';
			$val  = isset($pc['value']) ? (float) $pc['value'] : 0.0;

			if ('percent' === $type && $val > 0) { return $subtotal * ($val / 100.0); }
			if ('fixed' === $type && $val > 0) { return min($subtotal, $val); }
			return 0.0;
		}
		return 0.0;
	}
}
