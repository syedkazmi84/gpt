<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Config {

	public static function option_key() {
		return 'awpc_config_v1';
	}

	public static function default_config() {
		return array(
			'currency' => array(
				'code' => 'USD',
				'symbol' => '$',
				'position' => 'before',
				'thousand_sep' => ',',
				'decimal_sep' => '.',
				'tax_enabled' => false,
				'tax_rate' => 0,
			),
			'ui' => array(
				'default_tier' => 'standard',
				'enable_promo_codes' => true,
				'show_timeline_estimate' => true,
			),
			'security' => array(
				'rate_limit' => array(
					'max_per_hour' => 6,
				),
				'recaptcha' => array(
					'enabled' => false,
					'site_key' => '',
					'secret_key' => '',
				),
			),
			'webhook' => array(
				'enabled' => false,
				'url' => '',
			),
			'emails' => array(
				'admin_to' => get_option('admin_email'),
				'from_name' => 'AuthorWings',
				'from_email' => get_option('admin_email'),
				'admin_subject' => 'New quote request from {{name}}',
				'customer_subject' => 'Your AuthorWings quote summary',
				'admin_template' => "New quote request\n\nName: {{name}}\nEmail: {{email}}\nPhone: {{phone}}\n\nTotal: {{currency}}{{total}}\nTimeline: {{timeline}}\n\nSelected:\n{{items}}\n\nRaw:\n{{json}}",
				'customer_template' => "Hi {{name}},\n\nHere is your estimated quote summary.\n\nTotal: {{currency}}{{total}}\nTimeline: {{timeline}}\n\nSelected:\n{{items}}\n\nWe will contact you shortly.\n\nAuthorWings",
			),
			'lead_fields' => array(
				array('key' => 'name',  'label' => 'Full Name', 'type' => 'text', 'required' => true),
				array('key' => 'email', 'label' => 'Email',     'type' => 'email', 'required' => true),
				array('key' => 'phone', 'label' => 'Phone',     'type' => 'text', 'required' => false),
				array('key' => 'genre', 'label' => 'Book Genre','type' => 'text', 'required' => false),
				array('key' => 'word_count', 'label' => 'Manuscript Word Count', 'type' => 'number', 'required' => false),
			),
			'promo_codes' => array(
				array('code' => 'WELCOME10', 'type' => 'percent', 'value' => 10, 'usage_limit' => 100, 'used' => 0, 'expires' => ''),
			),
			'bundle_discounts' => array(
				array(
					'id' => 'edit_cover_bundle',
					'label' => 'Editing + Cover Design bundle',
					'requires' => array('editing', 'cover_design'),
					'type' => 'percent',
					'value' => 10,
				),
			),
			'services' => self::default_services(),
		);
	}

	private static function default_services() {
		return array(
			array(
				'id' => 'editing',
				'name' => 'Editing',
				'description' => 'Professional developmental and line editing tailored to your manuscript.',
				'category' => 'Editorial',
				'enabled' => true,
				'pricing' => array('model' => 'per_word','base' => 0,'unit_price' => 0.03),
				'tiers' => array('basic' => 1.0,'standard' => 1.25,'premium' => 1.6),
				'timeline_days' => array('base_days' => 10,'per_unit_days' => 2,'unit_size' => 10000),
				'options' => array(
					array('key' => 'rounds','label' => 'Revision Rounds','type' => 'number','min' => 1,'max' => 3,'step' => 1,'default' => 1,'price' => array('type' => 'multiplier', 'value' => 0.15)),
				),
			),
			array(
				'id' => 'proofreading',
				'name' => 'Proofreading',
				'description' => 'Final polish for grammar, punctuation, and consistency.',
				'category' => 'Editorial',
				'enabled' => true,
				'pricing' => array('model' => 'per_word','base' => 0,'unit_price' => 0.012),
				'tiers' => array('basic' => 1.0,'standard' => 1.2,'premium' => 1.4),
				'timeline_days' => array('base_days' => 7,'per_unit_days' => 1,'unit_size' => 10000),
				'options' => array(),
			),
			array(
				'id' => 'formatting',
				'name' => 'Formatting',
				'description' => 'Interior layout for ebook and print, aligned to your genre and trim size.',
				'category' => 'Design',
				'enabled' => true,
				'pricing' => array('model' => 'per_page','base' => 150,'unit_price' => 2.5),
				'tiers' => array('basic' => 1.0,'standard' => 1.15,'premium' => 1.35),
				'timeline_days' => array('base_days' => 8,'per_unit_days' => 1,'unit_size' => 100),
				'options' => array(
					array('key' => 'trim_size','label' => 'Trim Size','type' => 'select','choices' => array(
						array('value' => '5x8', 'label' => '5 x 8', 'price_delta' => 0),
						array('value' => '6x9', 'label' => '6 x 9', 'price_delta' => 0),
						array('value' => '8.5x11', 'label' => '8.5 x 11', 'price_delta' => 75),
					),'depends_on' => array('service' => 'formatting', 'selected' => true)),
					array('key' => 'interior_style','label' => 'Interior Style','type' => 'radio','choices' => array(
						array('value' => 'standard', 'label' => 'Standard', 'price_delta' => 0),
						array('value' => 'complex', 'label' => 'Complex (tables, charts)', 'price_delta' => 200),
					),'depends_on' => array('service' => 'formatting', 'selected' => true)),
				),
			),
			array(
				'id' => 'cover_design',
				'name' => 'Cover Design',
				'description' => 'Premium cover design with genre research and print-ready files.',
				'category' => 'Design',
				'enabled' => true,
				'pricing' => array('model' => 'flat','base' => 499,'unit_price' => 0),
				'tiers' => array('basic' => 1.0,'standard' => 1.25,'premium' => 1.6),
				'timeline_days' => array('base_days' => 10,'per_unit_days' => 0,'unit_size' => 1),
				'options' => array(
					array('key' => 'concepts','label' => 'Concept Options','type' => 'select','choices' => array(
						array('value' => '1', 'label' => '1 concept', 'price_delta' => 0),
						array('value' => '2', 'label' => '2 concepts', 'price_delta' => 150),
						array('value' => '3', 'label' => '3 concepts', 'price_delta' => 280),
					)),
				),
			),
			array(
				'id' => 'isbn',
				'name' => 'ISBN',
				'description' => 'ISBN allocation and listing guidance.',
				'category' => 'Publishing',
				'enabled' => true,
				'pricing' => array('model' => 'per_item','base' => 0,'unit_price' => 125),
				'tiers' => array('basic' => 1.0,'standard' => 1.0,'premium' => 1.0),
				'timeline_days' => array('base_days' => 2,'per_unit_days' => 0,'unit_size' => 1),
				'options' => array(),
			),
			array(
				'id' => 'distribution',
				'name' => 'Distribution',
				'description' => 'Setup for ebook and print distribution channels.',
				'category' => 'Publishing',
				'enabled' => true,
				'pricing' => array('model' => 'flat','base' => 299,'unit_price' => 0),
				'tiers' => array('basic' => 1.0,'standard' => 1.1,'premium' => 1.25),
				'timeline_days' => array('base_days' => 6,'per_unit_days' => 0,'unit_size' => 1),
				'options' => array(),
			),
			array(
				'id' => 'marketing',
				'name' => 'Marketing',
				'description' => 'Launch strategy, listings optimization, and optional ads support.',
				'category' => 'Marketing',
				'enabled' => true,
				'pricing' => array('model' => 'flat','base' => 599,'unit_price' => 0),
				'tiers' => array('basic' => 1.0,'standard' => 1.25,'premium' => 1.6),
				'timeline_days' => array('base_days' => 10,'per_unit_days' => 0,'unit_size' => 1),
				'options' => array(
					array('key' => 'ads_setup','label' => 'Ads Setup','type' => 'checkbox','price' => array('type' => 'flat', 'value' => 300)),
				),
			),
			array(
				'id' => 'ghostwriting',
				'name' => 'Ghostwriting',
				'description' => 'Professional ghostwriting aligned to your voice and goals.',
				'category' => 'Writing',
				'enabled' => true,
				'pricing' => array('model' => 'per_word','base' => 0,'unit_price' => 0.15),
				'tiers' => array('basic' => 1.0,'standard' => 1.15,'premium' => 1.3),
				'timeline_days' => array('base_days' => 21,'per_unit_days' => 7,'unit_size' => 10000),
				'options' => array(),
			),
		);
	}

	public function get() {
		$config = get_option(self::option_key(), array());
		if (!is_array($config)) { $config = array(); }
		$defaults = self::default_config();
		return array_replace_recursive($defaults, $config);
	}

	public function update($config) {
		if (!is_array($config)) { return false; }
		return update_option(self::option_key(), $config, false);
	}
}
