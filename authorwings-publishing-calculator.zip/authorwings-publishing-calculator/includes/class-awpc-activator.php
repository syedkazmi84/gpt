<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_Activator {

	public static function activate() {
		self::create_tables();
		self::maybe_seed_defaults();
	}

	private static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = $wpdb->prefix . 'awpc_submissions';
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'new',
			customer_name VARCHAR(190) NOT NULL DEFAULT '',
			customer_email VARCHAR(190) NOT NULL DEFAULT '',
			customer_phone VARCHAR(50) NOT NULL DEFAULT '',
			payload LONGTEXT NOT NULL,
			total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
			currency VARCHAR(10) NOT NULL DEFAULT 'USD',
			PRIMARY KEY (id),
			KEY created_at (created_at),
			KEY status (status),
			KEY customer_email (customer_email)
		) {$charset};";

		dbDelta($sql);
		update_option('awpc_db_version', '1');
	}

	private static function maybe_seed_defaults() {
		$config_key = AWPC_Config::option_key();
		$existing = get_option($config_key, null);
		if (is_array($existing)) {
			return;
		}
		$defaults = AWPC_Config::default_config();
		add_option($config_key, $defaults, '', false);
	}
}
