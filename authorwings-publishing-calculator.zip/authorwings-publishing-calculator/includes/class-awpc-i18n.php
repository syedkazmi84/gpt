<?php
namespace AuthorWings\PublishingCalculator;

defined('ABSPATH') || exit;

final class AWPC_I18n {
	public function load_textdomain() {
		load_plugin_textdomain(
			'authorwings-publishing-calculator',
			false,
			dirname(plugin_basename(__FILE__), 2) . '/languages/'
		);
	}
}
