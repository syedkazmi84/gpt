=== AuthorWings Publishing Calculator ===
Contributors: authorwings
Tags: calculator, quote, publishing, package builder
Requires at least: 6.2
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Hybrid publishing services calculator + make-your-own package builder with quote requests, promo codes, admin configuration, and export/import.
